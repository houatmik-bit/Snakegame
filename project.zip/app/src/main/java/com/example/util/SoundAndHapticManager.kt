package com.example.util

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.media.SoundPool
import android.media.ToneGenerator
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.sin
import kotlin.random.Random

class SoundAndHapticManager(private val context: Context) {

    private var soundPool: SoundPool? = null
    private var toneGenerator: ToneGenerator? = null

    private var soundIdEat: Int = 0
    private var soundIdBonus: Int = 0
    private var soundIdWallHit: Int = 0
    private var soundIdGameOver: Int = 0
    private var soundIdBomb: Int = 0
    private var soundIdCombo: Int = 0
    private var soundIdTurn: Int = 0

    private val vibrator: Vibrator? = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
        vibratorManager?.defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
    }

    init {
        try {
            toneGenerator = ToneGenerator(AudioManager.STREAM_MUSIC, 65)
        } catch (e: Exception) {
            Log.e("SoundManager", "Error initializing ToneGenerator", e)
        }

        initializeSoundPool()
    }

    private fun initializeSoundPool() {
        try {
            val audioAttributes = AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build()

            soundPool = SoundPool.Builder()
                .setMaxStreams(6)
                .setAudioAttributes(audioAttributes)
                .build()

            val cacheDir = File(context.cacheDir, "audio_sfx")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val eatFile = File(cacheDir, "sfx_eat.wav")
            val bonusFile = File(cacheDir, "sfx_bonus.wav")
            val wallHitFile = File(cacheDir, "sfx_wall_hit.wav")
            val gameOverFile = File(cacheDir, "sfx_game_over.wav")
            val bombFile = File(cacheDir, "sfx_bomb.wav")
            val comboFile = File(cacheDir, "sfx_combo.wav")
            val turnFile = File(cacheDir, "sfx_turn.wav")

            writeWavFile(eatFile, generateEatSound())
            writeWavFile(bonusFile, generateBonusSound())
            writeWavFile(wallHitFile, generateWallHitSound())
            writeWavFile(gameOverFile, generateGameOverSound())
            writeWavFile(bombFile, generateBombSound())
            writeWavFile(comboFile, generateComboSound())
            writeWavFile(turnFile, generateTurnSound())

            soundPool?.let { sp ->
                soundIdEat = sp.load(eatFile.absolutePath, 1)
                soundIdBonus = sp.load(bonusFile.absolutePath, 1)
                soundIdWallHit = sp.load(wallHitFile.absolutePath, 1)
                soundIdGameOver = sp.load(gameOverFile.absolutePath, 1)
                soundIdBomb = sp.load(bombFile.absolutePath, 1)
                soundIdCombo = sp.load(comboFile.absolutePath, 1)
                soundIdTurn = sp.load(turnFile.absolutePath, 1)
            }
        } catch (e: Exception) {
            Log.e("SoundManager", "Failed to init SoundPool, falling back to ToneGenerator", e)
        }
    }

    private fun writeWavFile(file: File, pcmSamples: ShortArray) {
        if (file.exists() && file.length() > 44) return
        try {
            val wavBytes = createWavBytes(pcmSamples, 44100)
            FileOutputStream(file).use { it.write(wavBytes) }
        } catch (e: Exception) {
            Log.e("SoundManager", "Failed to write WAV file ${file.name}", e)
        }
    }

    private fun createWavBytes(samples: ShortArray, sampleRate: Int): ByteArray {
        val byteDataSize = samples.size * 2
        val totalSize = 36 + byteDataSize
        val buffer = ByteBuffer.allocate(44 + byteDataSize).order(ByteOrder.LITTLE_ENDIAN)

        buffer.put("RIFF".toByteArray())
        buffer.putInt(totalSize)
        buffer.put("WAVE".toByteArray())
        buffer.put("fmt ".toByteArray())
        buffer.putInt(16)
        buffer.putShort(1)
        buffer.putShort(1)
        buffer.putInt(sampleRate)
        buffer.putInt(sampleRate * 2)
        buffer.putShort(2)
        buffer.putShort(16)
        buffer.put("data".toByteArray())
        buffer.putInt(byteDataSize)
        for (sample in samples) {
            buffer.putShort(sample)
        }
        return buffer.array()
    }

    private fun generateEatSound(): ShortArray {
        val sampleRate = 44100
        val numSamples = (sampleRate * 90) / 1000
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val progress = i.toDouble() / numSamples
            val freq = 480.0 + (progress * 420.0)
            val envelope = (1.0 - progress) * (1.0 - progress)
            val sine = sin(2.0 * PI * freq * t) + 0.25 * sin(4.0 * PI * freq * t)
            samples[i] = (sine * envelope * 24000.0).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    private fun generateBonusSound(): ShortArray {
        val sampleRate = 44100
        val numSamples = (sampleRate * 180) / 1000
        val samples = ShortArray(numSamples)
        val split = numSamples / 2
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val (freq, progress) = if (i < split) {
                Pair(660.0, i.toDouble() / split)
            } else {
                Pair(990.0, (i - split).toDouble() / (numSamples - split))
            }
            val envelope = 1.0 - progress
            val sine = sin(2.0 * PI * freq * t) + 0.3 * sin(4.0 * PI * freq * t)
            samples[i] = (sine * envelope * 26000.0).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    private fun generateWallHitSound(): ShortArray {
        val sampleRate = 44100
        val numSamples = (sampleRate * 160) / 1000
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val progress = i.toDouble() / numSamples
            val freq = 160.0 * (1.0 - progress * 0.7)
            val envelope = (1.0 - progress) * (1.0 - progress)
            val noise = (Random.nextDouble() * 2.0 - 1.0) * 0.35 * (1.0 - progress)
            val sine = sin(2.0 * PI * freq * t)
            val combined = (sine * 0.65 + noise) * envelope
            samples[i] = (combined * 28000.0).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    private fun generateGameOverSound(): ShortArray {
        val sampleRate = 44100
        val numSamples = (sampleRate * 520) / 1000
        val samples = ShortArray(numSamples)
        val notes = doubleArrayOf(440.0, 392.0, 349.0, 261.6)
        val samplesPerNote = numSamples / notes.size
        for (i in 0 until numSamples) {
            val noteIndex = (i / samplesPerNote).coerceAtMost(notes.size - 1)
            val noteProgress = (i % samplesPerNote).toDouble() / samplesPerNote
            val freq = notes[noteIndex]
            val t = i.toDouble() / sampleRate
            val vibrato = if (noteIndex == notes.size - 1) sin(2.0 * PI * 6.0 * t) * 6.0 else 0.0
            val envelope = 1.0 - (noteProgress * 0.8)
            val sine = sin(2.0 * PI * (freq + vibrato) * t) + 0.2 * sin(4.0 * PI * freq * t)
            samples[i] = (sine * envelope * 24000.0).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    private fun generateBombSound(): ShortArray {
        val sampleRate = 44100
        val numSamples = (sampleRate * 220) / 1000
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val envelope = (1.0 - progress) * (1.0 - progress)
            val noise = Random.nextDouble() * 2.0 - 1.0
            val lowRumble = sin(2.0 * PI * 65.0 * (i.toDouble() / sampleRate))
            val combined = (noise * 0.7 + lowRumble * 0.3) * envelope
            samples[i] = (combined * 27000.0).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    private fun generateComboSound(): ShortArray {
        val sampleRate = 44100
        val numSamples = (sampleRate * 130) / 1000
        val samples = ShortArray(numSamples)
        val split = numSamples / 2
        for (i in 0 until numSamples) {
            val t = i.toDouble() / sampleRate
            val (freq, progress) = if (i < split) {
                Pair(523.25, i.toDouble() / split)
            } else {
                Pair(783.99, (i - split).toDouble() / (numSamples - split))
            }
            val envelope = 1.0 - (progress * 0.7)
            val sine = sin(2.0 * PI * freq * t) + 0.3 * sin(3.0 * PI * freq * t)
            samples[i] = (sine * envelope * 25000.0).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    private fun generateTurnSound(): ShortArray {
        val sampleRate = 44100
        val numSamples = (sampleRate * 25) / 1000
        val samples = ShortArray(numSamples)
        for (i in 0 until numSamples) {
            val progress = i.toDouble() / numSamples
            val t = i.toDouble() / sampleRate
            val envelope = 1.0 - progress
            val sine = sin(2.0 * PI * 1100.0 * t)
            samples[i] = (sine * envelope * 12000.0).toInt().coerceIn(-32767, 32767).toShort()
        }
        return samples
    }

    fun playEatSound(isSoundEnabled: Boolean) {
        if (!isSoundEnabled) return
        val played = soundPool?.play(soundIdEat, 1f, 1f, 1, 0, 1f) ?: 0
        if (played == 0) {
            runCatching { toneGenerator?.startTone(ToneGenerator.TONE_PROP_BEEP, 80) }
        }
    }

    fun playBonusSound(isSoundEnabled: Boolean) {
        if (!isSoundEnabled) return
        val played = soundPool?.play(soundIdBonus, 1f, 1f, 1, 0, 1f) ?: 0
        if (played == 0) {
            runCatching { toneGenerator?.startTone(ToneGenerator.TONE_PROP_ACK, 140) }
        }
    }

    fun playWallHitSound(isSoundEnabled: Boolean) {
        if (!isSoundEnabled) return
        val played = soundPool?.play(soundIdWallHit, 1f, 1f, 2, 0, 1f) ?: 0
        if (played == 0) {
            runCatching { toneGenerator?.startTone(ToneGenerator.TONE_CDMA_ABBR_ALERT, 160) }
        }
    }

    fun playGameOverSound(isSoundEnabled: Boolean) {
        if (!isSoundEnabled) return
        val played = soundPool?.play(soundIdGameOver, 1f, 1f, 2, 0, 1f) ?: 0
        if (played == 0) {
            runCatching { toneGenerator?.startTone(ToneGenerator.TONE_CDMA_SOFT_ERROR_LITE, 360) }
        }
    }

    fun playBombSound(isSoundEnabled: Boolean) {
        if (!isSoundEnabled) return
        val played = soundPool?.play(soundIdBomb, 1f, 1f, 1, 0, 1f) ?: 0
        if (played == 0) {
            runCatching { toneGenerator?.startTone(ToneGenerator.TONE_SUP_ERROR, 220) }
        }
    }

    fun playComboSound(combo: Int, isSoundEnabled: Boolean) {
        if (!isSoundEnabled) return
        val rate = (1.0f + (combo - 1) * 0.15f).coerceIn(0.8f, 2.0f)
        val played = soundPool?.play(soundIdCombo, 1f, 1f, 1, 0, rate) ?: 0
        if (played == 0) {
            runCatching {
                val tone = if (combo >= 3) ToneGenerator.TONE_PROP_ACK else ToneGenerator.TONE_PROP_BEEP2
                toneGenerator?.startTone(tone, 100)
            }
        }
    }

    fun playTurnSound(isSoundEnabled: Boolean) {
        if (!isSoundEnabled) return
        val played = soundPool?.play(soundIdTurn, 0.45f, 0.45f, 0, 0, 1f) ?: 0
        if (played == 0) {
            runCatching { toneGenerator?.startTone(ToneGenerator.TONE_PROP_PROMPT, 30) }
        }
    }

    fun vibrateShort(isHapticEnabled: Boolean) {
        val vib = vibrator ?: return
        if (!isHapticEnabled || !vib.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(25)
            }
        }
    }

    fun vibrateEat(isHapticEnabled: Boolean) {
        val vib = vibrator ?: return
        if (!isHapticEnabled || !vib.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                vib.vibrate(VibrationEffect.createOneShot(45, VibrationEffect.DEFAULT_AMPLITUDE))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(45)
            }
        }
    }

    fun vibrateBomb(isHapticEnabled: Boolean) {
        val vib = vibrator ?: return
        if (!isHapticEnabled || !vib.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val timings = longArrayOf(0, 50, 40, 70)
                val amplitudes = intArrayOf(0, 220, 0, 255)
                vib.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(longArrayOf(0, 50, 40, 70), -1)
            }
        }
    }

    fun vibrateCollision(isHapticEnabled: Boolean) {
        val vib = vibrator ?: return
        if (!isHapticEnabled || !vib.hasVibrator()) return
        runCatching {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val timings = longArrayOf(0, 70, 50, 100)
                val amplitudes = intArrayOf(0, 200, 0, 255)
                vib.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vib.vibrate(longArrayOf(0, 70, 50, 100), -1)
            }
        }
    }

    fun release() {
        soundPool?.release()
        soundPool = null
        toneGenerator?.release()
        toneGenerator = null
    }
}
