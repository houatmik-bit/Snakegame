package com.example.util

import android.content.Context
import android.content.SharedPreferences
import com.example.model.BoardTheme
import com.example.model.ControlsType
import com.example.model.GameMode
import com.example.model.GameSpeed
import com.example.model.SnakeSkin

class GamePreferences(context: Context) {
    private val prefs: SharedPreferences =
        context.getSharedPreferences("snake_game_prefs", Context.MODE_PRIVATE)

    fun getHighScore(mode: GameMode): Int = prefs.getInt("high_score_${mode.name}", 0)

    fun setHighScore(mode: GameMode, score: Int) {
        val current = getHighScore(mode)
        if (score > current) {
            prefs.edit().putInt("high_score_${mode.name}", score).apply()
        }
    }

    fun getTotalApplesEaten(): Int = prefs.getInt("total_apples", 0)

    fun incrementApplesEaten(amount: Int = 1) {
        val current = getTotalApplesEaten()
        prefs.edit().putInt("total_apples", current + amount).apply()
    }

    fun getGoldenApplesEaten(): Int = prefs.getInt("golden_apples", 0)

    fun incrementGoldenApples() {
        val current = getGoldenApplesEaten()
        prefs.edit().putInt("golden_apples", current + 1).apply()
    }

    fun getTotalGamesPlayed(): Int = prefs.getInt("total_games", 0)

    fun incrementGamesPlayed() {
        val current = getTotalGamesPlayed()
        prefs.edit().putInt("total_games", current + 1).apply()
    }

    fun getMaxLength(): Int = prefs.getInt("max_length", 4)

    fun updateMaxLength(length: Int) {
        val current = getMaxLength()
        if (length > current) {
            prefs.edit().putInt("max_length", length).apply()
        }
    }

    fun getHighestCombo(): Int = prefs.getInt("highest_combo", 1)

    fun updateHighestCombo(combo: Int) {
        val current = getHighestCombo()
        if (combo > current) {
            prefs.edit().putInt("highest_combo", combo).apply()
        }
    }

    fun getTotalXp(): Int = prefs.getInt("total_xp", 0)

    fun addXp(amount: Int) {
        val current = getTotalXp()
        prefs.edit().putInt("total_xp", current + amount).apply()
    }

    var selectedSkin: SnakeSkin
        get() {
            val name = prefs.getString("selected_skin", SnakeSkin.EMERALD.name)
            return runCatching { SnakeSkin.valueOf(name ?: SnakeSkin.EMERALD.name) }
                .getOrDefault(SnakeSkin.EMERALD)
        }
        set(value) = prefs.edit().putString("selected_skin", value.name).apply()

    var selectedBoardTheme: BoardTheme
        get() {
            val name = prefs.getString("selected_board_theme", BoardTheme.CYBER_GRID.name)
            return runCatching { BoardTheme.valueOf(name ?: BoardTheme.CYBER_GRID.name) }
                .getOrDefault(BoardTheme.CYBER_GRID)
        }
        set(value) = prefs.edit().putString("selected_board_theme", value.name).apply()

    var selectedMode: GameMode
        get() {
            val name = prefs.getString("selected_mode", GameMode.CLASSIC.name)
            return runCatching { GameMode.valueOf(name ?: GameMode.CLASSIC.name) }
                .getOrDefault(GameMode.CLASSIC)
        }
        set(value) = prefs.edit().putString("selected_mode", value.name).apply()

    var selectedSpeed: GameSpeed
        get() {
            val name = prefs.getString("selected_speed", GameSpeed.NORMAL.name)
            return runCatching { GameSpeed.valueOf(name ?: GameSpeed.NORMAL.name) }
                .getOrDefault(GameSpeed.NORMAL)
        }
        set(value) = prefs.edit().putString("selected_speed", value.name).apply()

    var controlsType: ControlsType
        get() {
            val name = prefs.getString("controls_type", ControlsType.JOYSTICK.name)
            return runCatching { ControlsType.valueOf(name ?: ControlsType.JOYSTICK.name) }
                .getOrDefault(ControlsType.JOYSTICK)
        }
        set(value) = prefs.edit().putString("controls_type", value.name).apply()

    var isSoundEnabled: Boolean
        get() = prefs.getBoolean("sound_enabled", true)
        set(value) = prefs.edit().putBoolean("sound_enabled", value).apply()

    var isHapticEnabled: Boolean
        get() = prefs.getBoolean("haptic_enabled", true)
        set(value) = prefs.edit().putBoolean("haptic_enabled", value).apply()
}
