package com.example.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.Bolt
import androidx.compose.material.icons.rounded.Gamepad
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.KeyboardArrowUp
import androidx.compose.material.icons.rounded.Swipe
import androidx.compose.material.icons.rounded.TouchApp
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ControlsType
import com.example.model.Direction
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldBonus
import com.example.ui.theme.TextSecondary
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

@Composable
fun GameControlsSection(
    controlsType: ControlsType,
    currentDirection: Direction,
    isTurboActive: Boolean,
    onDirectionChanged: (Direction) -> Unit,
    onTurboChanged: (Boolean) -> Unit,
    onQuickSwitchControls: (ControlsType) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // شريط تبديل سريع بين الأنالوغ والأسهم
        Row(
            modifier = Modifier
                .clip(RoundedCornerShape(50))
                .background(DarkSurfaceVariant)
                .border(1.dp, DarkBorder, RoundedCornerShape(50))
                .padding(3.dp),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            QuickControlChip(
                label = "الأنالوغ",
                selected = controlsType == ControlsType.JOYSTICK,
                onClick = { onQuickSwitchControls(ControlsType.JOYSTICK) },
                testTag = "quick_toggle_joystick"
            )
            QuickControlChip(
                label = "الأسهم",
                selected = controlsType == ControlsType.DPAD,
                onClick = { onQuickSwitchControls(ControlsType.DPAD) },
                testTag = "quick_toggle_dpad"
            )
        }

        Spacer(modifier = Modifier.height(8.dp))

        // إبقاء عناصر الاتجاه بنظام LTR لضمان تطابق اليسار واليمين مع الشاشة فعلياً
        CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                when (controlsType) {
                    ControlsType.JOYSTICK -> {
                        AnalogJoystickPad(
                            currentDirection = currentDirection,
                            onDirectionChanged = onDirectionChanged
                        )
                    }

                    ControlsType.DPAD -> {
                        DirectionalArrowsPad(
                            currentDirection = currentDirection,
                            onDirectionChanged = onDirectionChanged
                        )
                    }

                    ControlsType.SWIPE -> {
                        ControlHintCard(
                            icon = Icons.Rounded.Swipe,
                            title = "التحكم بالسحب",
                            subtitle = "اسحب بإصبعك فوق اللوحة لتغيير الاتجاه"
                        )
                    }

                    ControlsType.TOUCH_QUADRANTS -> {
                        ControlHintCard(
                            icon = Icons.Rounded.TouchApp,
                            title = "اللمس الرباعي",
                            subtitle = "اضغط على أي جانب من اللوحة للاتجاه نحوه"
                        )
                    }
                }

                TurboBoostButton(
                    isTurboActive = isTurboActive,
                    onTurboChanged = onTurboChanged
                )
            }
        }
    }
}

@Composable
private fun QuickControlChip(
    label: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .height(34.dp)
            .clip(RoundedCornerShape(50))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(50),
        color = if (selected) EmeraldPrimary else Color.Transparent
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 16.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) Color.Black else TextSecondary
            )
        }
    }
}

/**
 * وحدة تحكم الأنالوغ (Analog Joystick) التفاعلية
 */
@Composable
fun AnalogJoystickPad(
    currentDirection: Direction,
    onDirectionChanged: (Direction) -> Unit,
    modifier: Modifier = Modifier
) {
    var knobOffset by remember { mutableStateOf(Offset.Zero) }
    var activeDir by remember { mutableStateOf<Direction?>(null) }
    var padSize by remember { mutableStateOf(IntSize.Zero) }

    val primaryColor = MaterialTheme.colorScheme.primary

    Box(
        modifier = modifier
            .size(144.dp)
            .onSizeChanged { padSize = it }
            .clip(CircleShape)
            .background(
                Brush.radialGradient(
                    colors = listOf(
                        DarkSurfaceVariant,
                        DarkSurface
                    )
                )
            )
            .border(2.dp, DarkBorder, CircleShape)
            .testTag("analog_joystick")
            .pointerInput(Unit) {
                detectDragGestures(
                    onDragStart = { startOffset ->
                        val center = Offset(padSize.width / 2f, padSize.height / 2f)
                        val maxRadius = (minOf(padSize.width, padSize.height) / 2f) * 0.62f
                        val delta = startOffset - center
                        val dist = hypot(delta.x, delta.y)
                        val clamped = if (dist > maxRadius && dist > 0f) {
                            Offset(delta.x / dist * maxRadius, delta.y / dist * maxRadius)
                        } else {
                            delta
                        }
                        knobOffset = clamped
                        resolveJoystickDirection(clamped, maxRadius)?.let { dir ->
                            if (dir != activeDir) {
                                activeDir = dir
                                onDirectionChanged(dir)
                            }
                        }
                    },
                    onDrag = { change, dragAmount ->
                        change.consume()
                        val maxRadius = (minOf(padSize.width, padSize.height) / 2f) * 0.62f
                        val next = knobOffset + dragAmount
                        val dist = hypot(next.x, next.y)
                        val clamped = if (dist > maxRadius && dist > 0f) {
                            Offset(next.x / dist * maxRadius, next.y / dist * maxRadius)
                        } else {
                            next
                        }
                        knobOffset = clamped
                        resolveJoystickDirection(clamped, maxRadius)?.let { dir ->
                            if (dir != activeDir) {
                                activeDir = dir
                                onDirectionChanged(dir)
                            }
                        }
                    },
                    onDragEnd = {
                        knobOffset = Offset.Zero
                        activeDir = null
                    },
                    onDragCancel = {
                        knobOffset = Offset.Zero
                        activeDir = null
                    }
                )
            },
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(144.dp)) {
            val center = Offset(size.width / 2f, size.height / 2f)
            val ringRadius = size.minDimension * 0.36f

            // حلقة داخلية إرشادية
            drawCircle(
                color = primaryColor.copy(alpha = 0.16f),
                radius = ringRadius,
                center = center,
                style = androidx.compose.ui.graphics.drawscope.Stroke(width = 3f)
            )

            // علامات الاتجاهات الأربعة
            val tickOffset = size.minDimension * 0.42f
            val dirPoints = listOf(
                Direction.UP to Offset(center.x, center.y - tickOffset),
                Direction.DOWN to Offset(center.x, center.y + tickOffset),
                Direction.LEFT to Offset(center.x - tickOffset, center.y),
                Direction.RIGHT to Offset(center.x + tickOffset, center.y)
            )
            dirPoints.forEach { (dir, pt) ->
                val isLit = (activeDir ?: currentDirection) == dir
                drawCircle(
                    color = if (isLit) primaryColor else Color.White.copy(alpha = 0.22f),
                    radius = if (isLit) 7f else 4.5f,
                    center = pt
                )
            }

            // المقبض المتحرك (الأنالوغ)
            val knobCenter = center + knobOffset
            drawCircle(
                color = primaryColor.copy(alpha = 0.28f),
                radius = 34.dp.toPx(),
                center = knobCenter
            )
            drawCircle(
                brush = Brush.radialGradient(
                    colors = listOf(
                        primaryColor,
                        primaryColor.copy(alpha = 0.72f)
                    ),
                    center = knobCenter,
                    radius = 24.dp.toPx()
                ),
                radius = 24.dp.toPx(),
                center = knobCenter
            )
            drawCircle(
                color = Color.White.copy(alpha = 0.4f),
                radius = 8.dp.toPx(),
                center = knobCenter - Offset(5.dp.toPx(), 5.dp.toPx())
            )
        }
    }
}

private fun resolveJoystickDirection(offset: Offset, maxRadius: Float): Direction? {
    if (maxRadius <= 0f) return null
    val dist = hypot(offset.x, offset.y)
    if (dist < maxRadius * 0.24f) return null
    val angleDeg = Math.toDegrees(atan2(offset.y.toDouble(), offset.x.toDouble()))
    return when {
        angleDeg >= -45 && angleDeg <= 45 -> Direction.RIGHT
        angleDeg > 45 && angleDeg < 135 -> Direction.DOWN
        angleDeg >= 135 || angleDeg <= -135 -> Direction.LEFT
        else -> Direction.UP
    }
}

/**
 * وحدة تحكم الأسهم (D-Pad) بأحجام لمس مريحة >= 48dp
 */
@Composable
fun DirectionalArrowsPad(
    currentDirection: Direction,
    onDirectionChanged: (Direction) -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier.testTag("dpad_controls"),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        ArrowKeyButton(
            icon = Icons.Rounded.KeyboardArrowUp,
            contentDescription = "أعلى",
            isActive = currentDirection == Direction.UP,
            onClick = { onDirectionChanged(Direction.UP) },
            testTag = "dpad_up"
        )
        Row(
            horizontalArrangement = Arrangement.spacedBy(20.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            ArrowKeyButton(
                icon = Icons.AutoMirrored.Rounded.KeyboardArrowLeft,
                contentDescription = "يسار",
                isActive = currentDirection == Direction.LEFT,
                onClick = { onDirectionChanged(Direction.LEFT) },
                testTag = "dpad_left"
            )
            Box(
                modifier = Modifier
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(DarkSurfaceVariant)
                    .border(1.dp, DarkBorder, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Rounded.Gamepad,
                    contentDescription = null,
                    tint = TextSecondary,
                    modifier = Modifier.size(16.dp)
                )
            }
            ArrowKeyButton(
                icon = Icons.AutoMirrored.Rounded.KeyboardArrowRight,
                contentDescription = "يمين",
                isActive = currentDirection == Direction.RIGHT,
                onClick = { onDirectionChanged(Direction.RIGHT) },
                testTag = "dpad_right"
            )
        }
        ArrowKeyButton(
            icon = Icons.Rounded.KeyboardArrowDown,
            contentDescription = "أسفل",
            isActive = currentDirection == Direction.DOWN,
            onClick = { onDirectionChanged(Direction.DOWN) },
            testTag = "dpad_down"
        )
    }
}

@Composable
private fun ArrowKeyButton(
    icon: ImageVector,
    contentDescription: String,
    isActive: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()
    val highlighted = isPressed || isActive

    Surface(
        onClick = onClick,
        interactionSource = interactionSource,
        modifier = Modifier
            .size(52.dp)
            .testTag(testTag),
        shape = RoundedCornerShape(16.dp),
        color = if (highlighted) EmeraldPrimary.copy(alpha = 0.22f) else DarkSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(
            width = if (highlighted) 1.8.dp else 1.dp,
            color = if (highlighted) EmeraldPrimary else DarkBorder
        )
    ) {
        Box(contentAlignment = Alignment.Center) {
            Icon(
                imageVector = icon,
                contentDescription = contentDescription,
                tint = if (highlighted) EmeraldPrimary else Color.White,
                modifier = Modifier.size(30.dp)
            )
        }
    }
}

@Composable
private fun ControlHintCard(
    icon: ImageVector,
    title: String,
    subtitle: String
) {
    Surface(
        shape = RoundedCornerShape(18.dp),
        color = DarkSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder),
        modifier = Modifier.width(210.dp)
    ) {
        Column(
            modifier = Modifier.padding(14.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = EmeraldPrimary,
                modifier = Modifier.size(32.dp)
            )
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = title,
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = subtitle,
                style = MaterialTheme.typography.bodySmall,
                color = TextSecondary
            )
        }
    }
}

@Composable
private fun TurboBoostButton(
    isTurboActive: Boolean,
    onTurboChanged: (Boolean) -> Unit
) {
    Surface(
        modifier = Modifier
            .size(72.dp)
            .clip(CircleShape)
            .border(
                width = 2.dp,
                color = if (isTurboActive) GoldBonus else DarkBorder,
                shape = CircleShape
            )
            .testTag("turbo_button")
            .pointerInput(Unit) {
                detectTapGestures(
                    onPress = {
                        onTurboChanged(true)
                        tryAwaitRelease()
                        onTurboChanged(false)
                    }
                )
            },
        shape = CircleShape,
        color = if (isTurboActive) GoldBonus.copy(alpha = 0.26f) else DarkSurfaceVariant
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Rounded.Bolt,
                contentDescription = "تسريع تيربو",
                tint = if (isTurboActive) GoldBonus else Color.White,
                modifier = Modifier.size(28.dp)
            )
            Text(
                text = "تيربو",
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = if (isTurboActive) GoldBonus else TextSecondary
            )
        }
    }
}
