package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.PauseCircle
import androidx.compose.material.icons.rounded.Vibration
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.model.BoardTheme
import com.example.model.ControlsType
import com.example.model.GameMode
import com.example.model.GameSpeed
import com.example.model.SnakeSkin
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldBonus
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.SnakeUiState

@Composable
fun SettingsAndSkinsDialog(
    uiState: SnakeUiState,
    onSelectControls: (ControlsType) -> Unit,
    onSelectMode: (GameMode) -> Unit,
    onSelectSpeed: (GameSpeed) -> Unit,
    onSelectSkin: (SnakeSkin) -> Unit,
    onSelectTheme: (BoardTheme) -> Unit,
    onToggleSound: () -> Unit,
    onToggleHaptic: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .heightIn(max = 640.dp)
                .border(1.5.dp, DarkBorder, RoundedCornerShape(24.dp))
                .testTag("settings_dialog"),
            shape = RoundedCornerShape(24.dp),
            color = DarkSurface
        ) {
            Column(
                modifier = Modifier.padding(20.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "الإعدادات والمظهر",
                        style = MaterialTheme.typography.titleLarge,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(48.dp)
                            .testTag("settings_close_icon")
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = "إغلاق الإعدادات",
                            tint = Color.White
                        )
                    }
                }

                // إشعار يوضح توقف اللعبة تلقائياً أثناء وجود اللاعب في الإعدادات
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("settings_paused_notice"),
                    shape = RoundedCornerShape(12.dp),
                    color = GoldBonus.copy(alpha = 0.14f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldBonus.copy(alpha = 0.45f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Rounded.PauseCircle,
                            contentDescription = null,
                            tint = GoldBonus,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "اللعبة متوقفة تلقائياً حتى تخرج من الإعدادات",
                            style = MaterialTheme.typography.bodySmall,
                            fontWeight = FontWeight.SemiBold,
                            color = GoldBonus
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Column(
                    modifier = Modifier
                        .weight(1f, fill = false)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    // طريقة التحكم
                    SettingsSectionTitle("طريقة التحكم")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        ControlsType.entries.forEach { ctrl ->
                            SelectionChip(
                                title = ctrl.titleAr,
                                selected = uiState.controlsType == ctrl,
                                onClick = { onSelectControls(ctrl) },
                                testTag = "control_option_${ctrl.name.lowercase()}"
                            )
                        }
                    }

                    // وضع اللعب
                    SettingsSectionTitle("وضع اللعب")
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        GameMode.entries.forEach { mode ->
                            val selected = uiState.mode == mode
                            Surface(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { onSelectMode(mode) }
                                    .testTag("mode_option_${mode.name.lowercase()}"),
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) EmeraldPrimary.copy(alpha = 0.16f) else DarkSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (selected) 1.5.dp else 1.dp,
                                    color = if (selected) EmeraldPrimary else DarkBorder
                                )
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Text(
                                        text = mode.titleAr,
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = if (selected) EmeraldPrimary else Color.White
                                    )
                                    Text(
                                        text = mode.descAr,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = TextSecondary
                                    )
                                }
                            }
                        }
                    }

                    // السرعة
                    SettingsSectionTitle("سرعة الأفعى")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        GameSpeed.entries.forEach { spd ->
                            SelectionChip(
                                title = spd.titleAr,
                                selected = uiState.speed == spd,
                                onClick = { onSelectSpeed(spd) },
                                testTag = "speed_option_${spd.name.lowercase()}"
                            )
                        }
                    }

                    // ألوان الأفعى
                    SettingsSectionTitle("شكل الأفعى")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        SnakeSkin.entries.forEach { skin ->
                            val selected = uiState.skin == skin
                            Surface(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(14.dp))
                                    .clickable { onSelectSkin(skin) },
                                shape = RoundedCornerShape(14.dp),
                                color = if (selected) EmeraldPrimary.copy(alpha = 0.18f) else DarkSurfaceVariant,
                                border = androidx.compose.foundation.BorderStroke(
                                    width = if (selected) 1.5.dp else 1.dp,
                                    color = if (selected) EmeraldPrimary else DarkBorder
                                )
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 12.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(16.dp)
                                            .clip(CircleShape)
                                            .background(Color(skin.headColorHex))
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = skin.titleAr,
                                        style = MaterialTheme.typography.labelLarge,
                                        color = Color.White
                                    )
                                }
                            }
                        }
                    }

                    // سمة اللوحة
                    SettingsSectionTitle("مظهر الساحة")
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        BoardTheme.entries.forEach { theme ->
                            SelectionChip(
                                title = theme.titleAr,
                                selected = uiState.boardTheme == theme,
                                onClick = { onSelectTheme(theme) },
                                testTag = "theme_option_${theme.name.lowercase()}"
                            )
                        }
                    }

                    // الصوت والاهتزاز
                    SettingsSectionTitle("الصوت والاهتزاز")
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = DarkSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, DarkBorder)
                    ) {
                        Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 6.dp)) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (uiState.isSoundEnabled) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff,
                                        contentDescription = null,
                                        tint = EmeraldPrimary
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text("المؤثرات الصوتية", color = Color.White)
                                }
                                Switch(
                                    checked = uiState.isSoundEnabled,
                                    onCheckedChange = { onToggleSound() },
                                    colors = SwitchDefaults.colors(checkedTrackColor = EmeraldPrimary),
                                    modifier = Modifier.testTag("sound_switch")
                                )
                            }

                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .heightIn(min = 48.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = Icons.Rounded.Vibration,
                                        contentDescription = null,
                                        tint = EmeraldPrimary
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text("الاهتزاز التفاعلي", color = Color.White)
                                }
                                Switch(
                                    checked = uiState.isHapticEnabled,
                                    onCheckedChange = { onToggleHaptic() },
                                    colors = SwitchDefaults.colors(checkedTrackColor = EmeraldPrimary),
                                    modifier = Modifier.testTag("haptic_switch")
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(50.dp)
                        .testTag("settings_done_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = EmeraldPrimary,
                        contentColor = Color.Black
                    )
                ) {
                    Text(
                        text = "حفظ والعودة للّعب",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }
    }
}

@Composable
private fun SettingsSectionTitle(title: String) {
    Text(
        text = title,
        style = MaterialTheme.typography.titleSmall,
        fontWeight = FontWeight.Bold,
        color = TextSecondary
    )
}

@Composable
private fun SelectionChip(
    title: String,
    selected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Surface(
        modifier = Modifier
            .heightIn(min = 48.dp)
            .clip(RoundedCornerShape(14.dp))
            .clickable(onClick = onClick)
            .testTag(testTag),
        shape = RoundedCornerShape(14.dp),
        color = if (selected) EmeraldPrimary else DarkSurfaceVariant,
        border = androidx.compose.foundation.BorderStroke(
            width = 1.dp,
            color = if (selected) EmeraldPrimary else DarkBorder
        )
    ) {
        Box(
            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = title,
                style = MaterialTheme.typography.labelLarge,
                fontWeight = if (selected) FontWeight.Bold else FontWeight.Medium,
                color = if (selected) Color.Black else Color.White
            )
        }
    }
}
