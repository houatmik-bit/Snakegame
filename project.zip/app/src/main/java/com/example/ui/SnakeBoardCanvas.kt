package com.example.ui

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import com.example.model.ControlsType
import com.example.model.Direction
import com.example.model.Food
import com.example.model.FoodType
import com.example.model.Point
import com.example.model.SnakeSkin
import com.example.ui.theme.FoodRed
import com.example.ui.theme.FoodRedGlow
import com.example.ui.theme.GoldBonus
import com.example.ui.theme.GoldGlow
import com.example.ui.theme.RainbowColors
import com.example.ui.theme.SpeedBlue
import com.example.ui.theme.StarPurple
import com.example.viewmodel.SnakeUiState
import kotlin.math.abs

@Composable
fun SnakeBoardCanvas(
    uiState: SnakeUiState,
    onDirectionChanged: (Direction) -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "board_pulse")
    val pulse by infiniteTransition.animateFloat(
        initialValue = 0.88f,
        targetValue = 1.14f,
        animationSpec = infiniteRepeatable(
            animation = tween(750, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "food_pulse"
    )

    var totalDragX by remember { mutableFloatStateOf(0f) }
    var totalDragY by remember { mutableFloatStateOf(0f) }
    var dragHandled by remember { mutableFloatStateOf(0f) }

    val bgColor = Color(uiState.boardTheme.bgHex)
    val gridColor = Color(uiState.boardTheme.gridLineHex)
    val borderColor = Color(uiState.boardTheme.borderHex)
    val isGhostActive = uiState.activePowerUps.any {
        it.type == FoodType.GHOST && it.expiresAtMillis > System.currentTimeMillis()
    }
    val isShieldActive = uiState.activePowerUps.any {
        it.type == FoodType.STAR && it.expiresAtMillis > System.currentTimeMillis()
    }

    val popupPaint = remember {
        Paint().apply {
            isAntiAlias = true
            textAlign = Paint.Align.CENTER
            typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
        }
    }

    val boardRatio = uiState.gridWidth.toFloat() / uiState.gridHeight.toFloat()

    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Ltr) {
        Box(
            modifier = modifier
                .aspectRatio(boardRatio)
                .clip(RoundedCornerShape(18.dp))
                .background(bgColor)
                .border(2.dp, borderColor, RoundedCornerShape(18.dp))
                .testTag("snake_board")
                .pointerInput(uiState.controlsType, uiState.isPaused, uiState.isSettingsOpen, uiState.isGameOver) {
                    detectDragGestures(
                        onDragStart = {
                            totalDragX = 0f
                            totalDragY = 0f
                            dragHandled = 0f
                        },
                        onDrag = { change, dragAmount ->
                            change.consume()
                            totalDragX += dragAmount.x
                            totalDragY += dragAmount.y
                            val threshold = 32f
                            if (dragHandled == 0f && (abs(totalDragX) > threshold || abs(totalDragY) > threshold)) {
                                val dir = if (abs(totalDragX) > abs(totalDragY)) {
                                    if (totalDragX > 0) Direction.RIGHT else Direction.LEFT
                                } else {
                                    if (totalDragY > 0) Direction.DOWN else Direction.UP
                                }
                                onDirectionChanged(dir)
                                dragHandled = 1f
                            }
                        }
                    )
                }
                .pointerInput(uiState.controlsType, uiState.isPaused, uiState.isSettingsOpen) {
                    if (uiState.controlsType == ControlsType.TOUCH_QUADRANTS) {
                        detectTapGestures { offset ->
                            val w = size.width.toFloat()
                            val h = size.height.toFloat()
                            val dx = (offset.x - w / 2f) / w
                            val dy = (offset.y - h / 2f) / h
                            val dir = if (abs(dx) > abs(dy)) {
                                if (dx > 0) Direction.RIGHT else Direction.LEFT
                            } else {
                                if (dy > 0) Direction.DOWN else Direction.UP
                            }
                            onDirectionChanged(dir)
                        }
                    }
                }
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val cellW = size.width / uiState.gridWidth
                val cellH = size.height / uiState.gridHeight

                // رسم خطوط الشبكة
                for (x in 1 until uiState.gridWidth) {
                    val px = x * cellW
                    drawLine(
                        color = gridColor,
                        start = Offset(px, 0f),
                        end = Offset(px, size.height),
                        strokeWidth = 1f
                    )
                }
                for (y in 1 until uiState.gridHeight) {
                    val py = y * cellH
                    drawLine(
                        color = gridColor,
                        start = Offset(0f, py),
                        end = Offset(size.width, py),
                        strokeWidth = 1f
                    )
                }

                // إظهار خطوط اللمس الرباعي عند اختياره
                if (uiState.controlsType == ControlsType.TOUCH_QUADRANTS) {
                    drawLine(
                        color = Color.White.copy(alpha = 0.08f),
                        start = Offset(0f, 0f),
                        end = Offset(size.width, size.height),
                        strokeWidth = 2f
                    )
                    drawLine(
                        color = Color.White.copy(alpha = 0.08f),
                        start = Offset(size.width, 0f),
                        end = Offset(0f, size.height),
                        strokeWidth = 2f
                    )
                }

                // رسم العوائق الحجرية
                uiState.obstacles.forEach { obs ->
                    val left = obs.x * cellW + cellW * 0.08f
                    val top = obs.y * cellH + cellH * 0.08f
                    val w = cellW * 0.84f
                    val h = cellH * 0.84f
                    drawRoundRect(
                        color = Color(0xFF475569),
                        topLeft = Offset(left, top),
                        size = Size(w, h),
                        cornerRadius = CornerRadius(cellW * 0.2f, cellH * 0.2f)
                    )
                    drawRoundRect(
                        color = Color(0xFF94A3B8).copy(alpha = 0.35f),
                        topLeft = Offset(left + 2f, top + 2f),
                        size = Size(w * 0.45f, h * 0.28f),
                        cornerRadius = CornerRadius(4f, 4f)
                    )
                }

                // رسم الغذاء الأساسي
                drawFoodItem(
                    food = uiState.food,
                    cellW = cellW,
                    cellH = cellH,
                    pulse = pulse
                )

                // رسم الغذاء الخاص الإضافي
                uiState.secondaryFood?.let { sec ->
                    drawFoodItem(
                        food = sec,
                        cellW = cellW,
                        cellH = cellH,
                        pulse = pulse
                    )
                }

                // رسم جسم الأفعى انطلاقاً من نموذج البيانات Snake
                val body = uiState.snake.body
                val totalLen = body.size.coerceAtLeast(1)
                for (index in body.indices.reversed()) {
                    val segment = body[index]
                    val isHead = index == 0
                    val ratio = 1f - (index.toFloat() / totalLen.toFloat()) * 0.38f

                    val baseColor = when (uiState.skin) {
                        SnakeSkin.RAINBOW -> RainbowColors[index % RainbowColors.size]
                        else -> if (isHead) Color(uiState.skin.headColorHex) else Color(uiState.skin.bodyColorHex)
                    }
                    val segColor = if (isGhostActive) baseColor.copy(alpha = 0.55f) else baseColor

                    val padX = cellW * (if (isHead) 0.04f else (1f - ratio * 0.86f) * 0.45f)
                    val padY = cellH * (if (isHead) 0.04f else (1f - ratio * 0.86f) * 0.45f)
                    val segLeft = segment.x * cellW + padX
                    val segTop = segment.y * cellH + padY
                    val segW = cellW - padX * 2f
                    val segH = cellH - padY * 2f

                    if (isHead && (isShieldActive || uiState.isTurboActive)) {
                        val auraColor = if (isShieldActive) StarPurple else Color(uiState.skin.glowColorHex)
                        drawCircle(
                            color = auraColor.copy(alpha = 0.32f),
                            radius = maxOf(cellW, cellH) * 0.72f,
                            center = Offset(
                                segment.x * cellW + cellW / 2f,
                                segment.y * cellH + cellH / 2f
                            )
                        )
                    }

                    drawRoundRect(
                        color = segColor,
                        topLeft = Offset(segLeft, segTop),
                        size = Size(segW, segH),
                        cornerRadius = CornerRadius(
                            x = if (isHead) cellW * 0.36f else cellW * 0.28f,
                            y = if (isHead) cellH * 0.36f else cellH * 0.28f
                        )
                    )

                    if (isHead) {
                        drawSnakeEyes(
                            head = segment,
                            direction = uiState.snake.direction,
                            cellW = cellW,
                            cellH = cellH
                        )
                    }
                }

                // رسم الجزيئات عند الأكل أو الانفجار
                uiState.particles.forEach { p ->
                    drawCircle(
                        color = p.color.copy(alpha = p.alpha.coerceIn(0f, 1f)),
                        radius = p.radius,
                        center = Offset(p.x * cellW, p.y * cellH)
                    )
                }

                // رسم نقاط المكافأة الطائرة
                uiState.scorePopups.forEach { pop ->
                    popupPaint.textSize = (cellW * 0.62f).coerceAtLeast(24f)
                    popupPaint.color = if (pop.isDanger) {
                        Color(0xFFEF4444).copy(alpha = pop.alpha.coerceIn(0f, 1f)).toArgb()
                    } else {
                        Color(0xFFFDE68A).copy(alpha = pop.alpha.coerceIn(0f, 1f)).toArgb()
                    }
                    drawContext.canvas.nativeCanvas.drawText(
                        pop.text,
                        pop.x * cellW,
                        pop.y * cellH,
                        popupPaint
                    )
                }
            }
        }
    }
}

private fun DrawScope.drawFoodItem(
    food: Food,
    cellW: Float,
    cellH: Float,
    pulse: Float
) {
    val cx = food.position.x * cellW + cellW / 2f
    val cy = food.position.y * cellH + cellH / 2f
    val baseRadius = minOf(cellW, cellH) * 0.38f * pulse

    val (coreColor, glowColor) = when (food.type) {
        FoodType.NORMAL -> FoodRed to FoodRedGlow
        FoodType.GOLDEN -> GoldBonus to GoldGlow
        FoodType.SLOW_MO -> SpeedBlue to Color(0xFF93C5FD)
        FoodType.STAR -> StarPurple to Color(0xFFD8B4FE)
        FoodType.POISON_BOMB -> Color(0xFF1F2937) to Color(0xFFEF4444)
        FoodType.DOUBLE_SCORE -> Color(0xFF10B981) to Color(0xFF6EE7B7)
        FoodType.MAGNET -> Color(0xFFEC4899) to Color(0xFFF9A8D4)
        FoodType.GHOST -> Color(0xFF38BDF8) to Color(0xFFBAE6FD)
    }

    // هالة مضيئة حول الغذاء
    drawCircle(
        brush = Brush.radialGradient(
            colors = listOf(glowColor.copy(alpha = 0.55f), Color.Transparent),
            center = Offset(cx, cy),
            radius = baseRadius * 1.85f
        ),
        radius = baseRadius * 1.85f,
        center = Offset(cx, cy)
    )

    // جسم الغذاء
    drawCircle(
        color = coreColor,
        radius = baseRadius,
        center = Offset(cx, cy)
    )

    // لمعة أو علامة مميزة
    if (food.type == FoodType.POISON_BOMB) {
        drawCircle(
            color = Color(0xFFEF4444),
            radius = baseRadius * 0.35f,
            center = Offset(cx, cy)
        )
    } else {
        drawCircle(
            color = Color.White.copy(alpha = 0.65f),
            radius = baseRadius * 0.28f,
            center = Offset(cx - baseRadius * 0.28f, cy - baseRadius * 0.28f)
        )
    }
}

private fun DrawScope.drawSnakeEyes(
    head: Point,
    direction: Direction,
    cellW: Float,
    cellH: Float
) {
    val cx = head.x * cellW + cellW / 2f
    val cy = head.y * cellH + cellH / 2f
    val eyeRadius = minOf(cellW, cellH) * 0.13f
    val pupilRadius = eyeRadius * 0.55f

    val forwardOffset = minOf(cellW, cellH) * 0.18f
    val sideOffset = minOf(cellW, cellH) * 0.21f

    val (eye1, eye2) = when (direction) {
        Direction.RIGHT -> Offset(cx + forwardOffset, cy - sideOffset) to Offset(cx + forwardOffset, cy + sideOffset)
        Direction.LEFT -> Offset(cx - forwardOffset, cy - sideOffset) to Offset(cx - forwardOffset, cy + sideOffset)
        Direction.UP -> Offset(cx - sideOffset, cy - forwardOffset) to Offset(cx + sideOffset, cy - forwardOffset)
        Direction.DOWN -> Offset(cx - sideOffset, cy + forwardOffset) to Offset(cx + sideOffset, cy + forwardOffset)
    }

    drawCircle(color = Color.White, radius = eyeRadius, center = eye1)
    drawCircle(color = Color.White, radius = eyeRadius, center = eye2)
    drawCircle(color = Color(0xFF0F172A), radius = pupilRadius, center = eye1)
    drawCircle(color = Color(0xFF0F172A), radius = pupilRadius, center = eye2)
}
