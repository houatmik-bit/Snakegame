package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.EmojiEvents
import androidx.compose.material.icons.rounded.Pause
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Settings
import androidx.compose.material.icons.rounded.VolumeOff
import androidx.compose.material.icons.rounded.VolumeUp
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.ui.theme.DarkBackground
import com.example.ui.theme.DarkBorder
import com.example.ui.theme.DarkSurface
import com.example.ui.theme.DarkSurfaceVariant
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.GoldBonus
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.SnakeUiState
import com.example.viewmodel.SnakeViewModel

@Composable
fun SnakeHomeScreen(
    viewModel: SnakeViewModel,
    modifier: Modifier = Modifier
) {
    // قراءة حالة اللعبة مباشرة من Jetpack Compose State
    val uiState = viewModel.uiState

    if (uiState.isSettingsOpen) {
        BackHandler { viewModel.closeSettings() }
    } else if (uiState.isStatsOpen) {
        BackHandler { viewModel.closeStats() }
    }

    Scaffold(
        modifier = modifier
            .fillMaxSize()
            .background(DarkBackground),
        containerColor = DarkBackground,
        contentWindowInsets = WindowInsets(0, 0, 0, 0)
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .statusBarsPadding()
                .navigationBarsPadding(),
            contentAlignment = Alignment.TopCenter
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .widthIn(max = 580.dp)
                    .padding(horizontal = 14.dp, vertical = 10.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // الشريط العلوي والأزرار
                TopHudBar(
                    uiState = uiState,
                    onTogglePause = viewModel::togglePause,
                    onRestart = viewModel::startNewGame,
                    onToggleSound = viewModel::toggleSound,
                    onOpenStats = viewModel::openStats,
                    onOpenSettings = viewModel::openSettings
                )

                // شريط النتيجة والطول والقدرات النشطة
                ScoreAndLengthStrip(uiState = uiState)

                // لوحة اللعب
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .padding(vertical = 8.dp),
                    contentAlignment = Alignment.Center
                ) {
                    SnakeBoardCanvas(
                        uiState = uiState,
                        onDirectionChanged = viewModel::onDirectionChanged,
                        modifier = Modifier.fillMaxSize()
                    )
                }

                // وحدة التحكم (الأنالوغ أو الأسهم أو السحب)
                GameControlsSection(
                    controlsType = uiState.controlsType,
                    currentDirection = uiState.snake.direction,
                    isTurboActive = uiState.isTurboActive,
                    onDirectionChanged = viewModel::onDirectionChanged,
                    onTurboChanged = viewModel::setTurboActive,
                    onQuickSwitchControls = viewModel::setControlsType
                )
            }

            // شاشة الإيقاف المؤقت (لا تظهر فوق نافذة الإعدادات)
            if (uiState.isPaused && !uiState.isGameOver && !uiState.isSettingsOpen && !uiState.isStatsOpen) {
                PausedOverlay(
                    score = uiState.score,
                    snakeLength = uiState.snake.length,
                    onResume = viewModel::togglePause,
                    onRestart = viewModel::startNewGame,
                    onOpenSettings = viewModel::openSettings
                )
            }

            // شاشة انتهاء اللعبة
            if (uiState.isGameOver) {
                GameOverDialog(
                    score = uiState.score,
                    highScore = uiState.highScore,
                    applesEaten = uiState.applesEatenThisGame,
                    snakeLength = uiState.snake.length,
                    deathReason = uiState.deathReason,
                    isNewRecord = uiState.isNewRecord,
                    canRevive = uiState.canRevive,
                    onRevive = viewModel::reviveGame,
                    onPlayAgain = viewModel::startNewGame
                )
            }

            // نافذة الإعدادات (توقف اللعبة تلقائياً حتى الخروج منها)
            if (uiState.isSettingsOpen) {
                SettingsAndSkinsDialog(
                    uiState = uiState,
                    onSelectControls = viewModel::setControlsType,
                    onSelectMode = viewModel::setGameModeKeepingSettingsState,
                    onSelectSpeed = viewModel::setGameSpeed,
                    onSelectSkin = viewModel::setSnakeSkin,
                    onSelectTheme = viewModel::setBoardTheme,
                    onToggleSound = viewModel::toggleSound,
                    onToggleHaptic = viewModel::toggleHaptic,
                    onDismiss = viewModel::closeSettings
                )
            }

            // نافذة الإحصائيات والمهام
            if (uiState.isStatsOpen) {
                StatsDialog(
                    uiState = uiState,
                    onDismiss = viewModel::closeStats
                )
            }
        }
    }
}

@Composable
private fun TopHudBar(
    uiState: SnakeUiState,
    onTogglePause: () -> Unit,
    onRestart: () -> Unit,
    onToggleSound: () -> Unit,
    onOpenStats: () -> Unit,
    onOpenSettings: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column {
            Text(
                text = "لعبة الأفعى",
                style = MaterialTheme.typography.titleLarge,
                fontWeight = FontWeight.ExtraBold,
                color = EmeraldPrimary
            )
            Text(
                text = "${uiState.mode.titleAr} • ${uiState.speed.titleAr}",
                style = MaterialTheme.typography.labelMedium,
                color = TextSecondary
            )
        }

        Row(
            horizontalArrangement = Arrangement.spacedBy(2.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggleSound,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("hud_sound_button")
            ) {
                Icon(
                    imageVector = if (uiState.isSoundEnabled) Icons.Rounded.VolumeUp else Icons.Rounded.VolumeOff,
                    contentDescription = "تبديل الصوت",
                    tint = if (uiState.isSoundEnabled) EmeraldPrimary else TextSecondary
                )
            }

            IconButton(
                onClick = onOpenStats,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("hud_stats_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.EmojiEvents,
                    contentDescription = "الإحصائيات والمهام",
                    tint = GoldBonus
                )
            }

            IconButton(
                onClick = onTogglePause,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("hud_pause_button")
            ) {
                Icon(
                    imageVector = if (uiState.isPaused) Icons.Rounded.PlayArrow else Icons.Rounded.Pause,
                    contentDescription = if (uiState.isPaused) "استئناف" else "إيقاف مؤقت",
                    tint = Color.White
                )
            }

            IconButton(
                onClick = onRestart,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("hud_restart_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Refresh,
                    contentDescription = "إعادة اللعبة",
                    tint = Color.White
                )
            }

            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(48.dp)
                    .testTag("hud_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Rounded.Settings,
                    contentDescription = "الإعدادات",
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
private fun ScoreAndLengthStrip(uiState: SnakeUiState) {
    val now = System.currentTimeMillis()
    val activePowers = uiState.activePowerUps.filter { it.expiresAtMillis > now }

    Column(
        modifier = Modifier.fillMaxWidth(),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            HudMetricCard(
                label = "النتيجة",
                value = "${uiState.score}",
                highlight = EmeraldPrimary,
                modifier = Modifier.weight(1f)
            )
            HudMetricCard(
                label = "الطول",
                value = "${uiState.snake.length}",
                highlight = Color(0xFF38BDF8),
                modifier = Modifier.weight(1f)
            )
            HudMetricCard(
                label = "أعلى رقم",
                value = "${uiState.highScore}",
                highlight = GoldBonus,
                modifier = Modifier.weight(1f)
            )
        }

        if (uiState.comboMultiplier > 1 || activePowers.isNotEmpty()) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (uiState.comboMultiplier > 1) {
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = GoldBonus.copy(alpha = 0.18f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, GoldBonus)
                    ) {
                        Text(
                            text = "كومبو x${uiState.comboMultiplier}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = GoldBonus,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
                activePowers.forEach { power ->
                    val secs = ((power.expiresAtMillis - now) / 1000L).coerceAtLeast(1L)
                    Surface(
                        shape = RoundedCornerShape(50),
                        color = DarkSurfaceVariant,
                        border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.6f))
                    ) {
                        Text(
                            text = "${power.type.titleAr} (${secs}ث)",
                            style = MaterialTheme.typography.labelMedium,
                            color = EmeraldPrimary,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HudMetricCard(
    label: String,
    value: String,
    highlight: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier.border(1.dp, DarkBorder, RoundedCornerShape(14.dp)),
        shape = RoundedCornerShape(14.dp),
        color = DarkSurface
    ) {
        Column(
            modifier = Modifier.padding(vertical = 8.dp, horizontal = 10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                style = MaterialTheme.typography.labelSmall,
                color = TextSecondary
            )
            Text(
                text = value,
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.ExtraBold,
                color = highlight
            )
        }
    }
}
