package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Neon / Emerald Arcade Palette
val EmeraldPrimary = Color(0xFF10B981)
val EmeraldPrimaryDark = Color(0xFF059669)
val EmeraldLight = Color(0xFF34D399)
val EmeraldGlow = Color(0xFF6EE7B7)

val DarkBackground = Color(0xFF0A0F14)
val DarkSurface = Color(0xFF131D26)
val DarkSurfaceVariant = Color(0xFF1C2A36)
val DarkBorder = Color(0xFF243647)

val FoodRed = Color(0xFFEF4444)
val FoodRedGlow = Color(0xFFF87171)
val GoldBonus = Color(0xFFF59E0B)
val GoldGlow = Color(0xFFFDE68A)
val SpeedBlue = Color(0xFF3B82F6)
val StarPurple = Color(0xFFA855F7)

val TextPrimary = Color(0xFFF1F5F9)
val TextSecondary = Color(0xFF94A3B8)
val TextMuted = Color(0xFF64748B)

// Skins colors
val GoldSnakeHead = Color(0xFFFBBF24)
val GoldSnakeBody = Color(0xFFD97706)

val CyberSnakeHead = Color(0xFF06B6D4)
val CyberSnakeBody = Color(0xFF0284C7)

val RainbowColors = listOf(
    Color(0xFFEF4444),
    Color(0xFFF97316),
    Color(0xFFFBBF24),
    Color(0xFF10B981),
    Color(0xFF06B6D4),
    Color(0xFF6366F1),
    Color(0xFFA855F7)
)
