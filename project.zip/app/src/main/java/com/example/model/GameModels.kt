package com.example.model

import androidx.compose.ui.graphics.Color

data class Point(
    val x: Int,
    val y: Int
)

enum class Direction {
    UP, DOWN, LEFT, RIGHT;

    fun isOpposite(other: Direction): Boolean = when (this) {
        UP -> other == DOWN
        DOWN -> other == UP
        LEFT -> other == RIGHT
        RIGHT -> other == LEFT
    }
}

/**
 * نموذج بيانات لتمثيل الأفعى:
 * [body] قائمة نقاط الجسم (أول نقطة هي الرأس).
 * [direction] الاتجاه الحالي لحركة الأفعى.
 * [pendingGrowth] مقدار النمو المنتظر عند تناول الغذاء.
 */
data class Snake(
    val body: List<Point>,
    val direction: Direction = Direction.RIGHT,
    val pendingGrowth: Int = 0
) {
    val head: Point
        get() = body.first()

    val length: Int
        get() = body.size
}

/**
 * نموذج بيانات لتمثيل الغذاء:
 * [position] موقع الغذاء على الشبكة.
 * [type] نوع الغذاء (عادي، ذهبي، تبطيء، نجمة، قنبلة، مضاعف، مغناطيس، شبح).
 * [expiresAtMillis] وقت انتهاء الصلاحية للأغذية الخاصة (0 يعني دائم).
 */
data class Food(
    val position: Point,
    val type: FoodType = FoodType.NORMAL,
    val expiresAtMillis: Long = 0L
)

enum class FoodType(
    val points: Int,
    val growth: Int,
    val durationSeconds: Int,
    val titleAr: String
) {
    NORMAL(10, 1, 0, "تفاحة"),
    GOLDEN(30, 2, 8, "تفاحة ذهبية"),
    SLOW_MO(15, 1, 6, "تبطيء السرعة"),
    STAR(40, 2, 6, "درع المناعة"),
    POISON_BOMB(-15, -1, 9, "قنبلة سامة"),
    DOUBLE_SCORE(20, 1, 8, "مضاعف 2X"),
    MAGNET(25, 1, 7, "مغناطيس"),
    GHOST(25, 1, 6, "الشبح العابر")
}

enum class GameMode(val titleAr: String, val descAr: String) {
    CLASSIC("كلاسيكي", "الاصطدام بالجدران ينهي اللعبة"),
    ENDLESS("عبور الجدران", "تلتف الأفعى وتخرج من الطرف المقابل"),
    OBSTACLES("متاهة العوائق", "حواجز وصخور تظهر لتحدي أكبر")
}

enum class GameSpeed(val titleAr: String, val baseDelayMs: Long) {
    SLOW("هادئ", 220L),
    NORMAL("متوسط", 150L),
    FAST("سريع", 95L),
    DYNAMIC("متسارع", 170L)
}

enum class SnakeSkin(
    val titleAr: String,
    val headColorHex: Long,
    val bodyColorHex: Long,
    val glowColorHex: Long
) {
    EMERALD("زمرد نيون", 0xFF10B981, 0xFF059669, 0xFF34D399),
    GOLDEN("كوبرا ذهبية", 0xFFFBBF24, 0xFFD97706, 0xFFFDE68A),
    CYBERPUNK("سايبر نيون", 0xFF06B6D4, 0xFF6366F1, 0xFF38BDF8),
    RUBY("ياقوت ناري", 0xFFF43F5E, 0xFFBE123C, 0xFFFDA4AF),
    DRAGON("تنين اللهب", 0xFFFF6D00, 0xFFD84315, 0xFFFFAB00),
    NOKIA_3310("نوكيا ريترو", 0xFF3D4E35, 0xFF283423, 0xFF7D9372),
    RAINBOW("ألوان الطيف", 0xFF10B981, 0xFF6366F1, 0xFFFBBF24)
}

enum class BoardTheme(
    val titleAr: String,
    val bgHex: Long,
    val gridLineHex: Long,
    val borderHex: Long
) {
    CYBER_GRID("الشبكة السيبرانية", 0xFF0F1720, 0x1838BDF8, 0xFF1E293B),
    RETRO_NOKIA("شاشة نوكيا 3310", 0xFF8BAC0F, 0x25306230, 0xFF306230),
    DESERT_DUNES("رمال الصحراء", 0xFF1A130E, 0x20F59E0B, 0xFF3D2718),
    DEEP_OASIS("واحة الغابة", 0xFF091A12, 0x2034D399, 0xFF133E2B)
}

enum class ControlsType(val titleAr: String) {
    JOYSTICK("الأنالوغ"),
    DPAD("الأسهم"),
    SWIPE("السحب"),
    TOUCH_QUADRANTS("اللمس الرباعي")
}

data class Particle(
    val x: Float,
    val y: Float,
    val vx: Float,
    val vy: Float,
    val color: Color,
    val alpha: Float = 1f,
    val radius: Float = 6f
)

data class ScorePopup(
    val x: Float,
    val y: Float,
    val text: String,
    val alpha: Float = 1f,
    val isDanger: Boolean = false
)

data class ActivePowerUp(
    val type: FoodType,
    val expiresAtMillis: Long
)

data class GameMission(
    val id: String,
    val titleAr: String,
    val descAr: String,
    val targetCount: Int,
    val currentCount: Int,
    val isCompleted: Boolean,
    val rewardScore: Int,
    val iconEmoji: String
)
