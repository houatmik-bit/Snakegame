package com.example.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.model.ActivePowerUp
import com.example.model.BoardTheme
import com.example.model.ControlsType
import com.example.model.Direction
import com.example.model.Food
import com.example.model.FoodType
import com.example.model.GameMission
import com.example.model.GameMode
import com.example.model.GameSpeed
import com.example.model.Particle
import com.example.model.Point
import com.example.model.ScorePopup
import com.example.model.Snake
import com.example.model.SnakeSkin
import com.example.ui.theme.EmeraldPrimary
import com.example.ui.theme.FoodRed
import com.example.ui.theme.GoldBonus
import com.example.ui.theme.SpeedBlue
import com.example.ui.theme.StarPurple
import com.example.util.GamePreferences
import com.example.util.SoundAndHapticManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.util.ArrayDeque
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.random.Random

/**
 * حالة اللعبة الكاملة المدارة عبر Jetpack Compose State.
 */
data class SnakeUiState(
    val gridWidth: Int = 20,
    val gridHeight: Int = 24,
    val snake: Snake = Snake(
        body = listOf(Point(10, 12), Point(9, 12), Point(8, 12), Point(7, 12)),
        direction = Direction.RIGHT,
        pendingGrowth = 0
    ),
    val food: Food = Food(Point(15, 12), FoodType.NORMAL),
    val secondaryFood: Food? = null,
    val obstacles: List<Point> = emptyList(),
    val score: Int = 0,
    val highScore: Int = 0,
    val applesEatenThisGame: Int = 0,
    val comboCount: Int = 0,
    val comboMultiplier: Int = 1,
    val lastEatTimeMillis: Long = 0L,
    val activePowerUps: List<ActivePowerUp> = emptyList(),
    val particles: List<Particle> = emptyList(),
    val scorePopups: List<ScorePopup> = emptyList(),
    val isPaused: Boolean = false,
    val isSettingsOpen: Boolean = false,
    val isStatsOpen: Boolean = false,
    val isGameOver: Boolean = false,
    val canRevive: Boolean = true,
    val isTurboActive: Boolean = false,
    val deathReason: String = "",
    val mode: GameMode = GameMode.CLASSIC,
    val speed: GameSpeed = GameSpeed.NORMAL,
    val skin: SnakeSkin = SnakeSkin.EMERALD,
    val boardTheme: BoardTheme = BoardTheme.CYBER_GRID,
    val controlsType: ControlsType = ControlsType.JOYSTICK,
    val isSoundEnabled: Boolean = true,
    val isHapticEnabled: Boolean = true,
    val totalGamesPlayed: Int = 0,
    val totalApplesEaten: Int = 0,
    val maxSnakeLength: Int = 4,
    val highestComboEver: Int = 1,
    val totalXp: Int = 0,
    val missions: List<GameMission> = emptyList(),
    val isNewRecord: Boolean = false
)

sealed interface SnakeStepResult {
    data class Moved(
        val snake: Snake,
        val eatenFood: Food?,
        val eatenSecondaryFood: Food?
    ) : SnakeStepResult

    data class Collided(val reason: String, val isWallHit: Boolean) : SnakeStepResult
}

/**
 * منطق حركة الأفعى ونمو طولها عند تناول الغذاء (نقي وقابل للاختبار).
 */
object SnakeGameLogic {

    fun nextHeadPosition(
        head: Point,
        direction: Direction,
        gridWidth: Int,
        gridHeight: Int,
        wrapAround: Boolean
    ): Point? {
        var nx = head.x
        var ny = head.y
        when (direction) {
            Direction.UP -> ny -= 1
            Direction.DOWN -> ny += 1
            Direction.LEFT -> nx -= 1
            Direction.RIGHT -> nx += 1
        }
        return if (nx !in 0 until gridWidth || ny !in 0 until gridHeight) {
            if (wrapAround) {
                Point(
                    x = (nx + gridWidth) % gridWidth,
                    y = (ny + gridHeight) % gridHeight
                )
            } else {
                null
            }
        } else {
            Point(nx, ny)
        }
    }

    fun advanceSnake(
        snake: Snake,
        nextDirection: Direction,
        gridWidth: Int,
        gridHeight: Int,
        mode: GameMode,
        obstacles: List<Point> = emptyList(),
        primaryFood: Food? = null,
        secondaryFood: Food? = null,
        isGhostActive: Boolean = false,
        isShieldActive: Boolean = false
    ): SnakeStepResult {
        val resolvedDirection = if (nextDirection.isOpposite(snake.direction)) {
            snake.direction
        } else {
            nextDirection
        }

        val wrapWalls = mode == GameMode.ENDLESS || isGhostActive
        val newHead = nextHeadPosition(
            head = snake.head,
            direction = resolvedDirection,
            gridWidth = gridWidth,
            gridHeight = gridHeight,
            wrapAround = wrapWalls
        ) ?: return SnakeStepResult.Collided(
            reason = "اصطدمت بالجدار!",
            isWallHit = true
        )

        if (!isGhostActive && !isShieldActive && obstacles.contains(newHead)) {
            return SnakeStepResult.Collided(
                reason = "اصطدمت بعائق حجري!",
                isWallHit = true
            )
        }

        val eatenPrimary = primaryFood?.takeIf { it.position == newHead }
        val eatenSecondary = secondaryFood?.takeIf { it.position == newHead }

        val foodGrowth = (eatenPrimary?.type?.growth ?: 0) + (eatenSecondary?.type?.growth ?: 0)
        val totalPendingGrowth = snake.pendingGrowth + foodGrowth

        val willGrowThisStep = totalPendingGrowth > 0
        val bodyToCheckSelf = if (willGrowThisStep) {
            snake.body
        } else {
            snake.body.dropLast(1)
        }

        if (!isGhostActive && !isShieldActive && bodyToCheckSelf.contains(newHead)) {
            return SnakeStepResult.Collided(
                reason = "التفت الأفعى على نفسها!",
                isWallHit = false
            )
        }

        val updatedBody = buildList {
            add(newHead)
            addAll(snake.body)
        }.let { expanded ->
            when {
                totalPendingGrowth > 0 -> {
                    // النمو يحافظ على الذيل ولا يحذفه في هذه الخطوة
                    expanded
                }
                totalPendingGrowth < 0 -> {
                    // قنبلة سامة تقلّص الذيل مع الحفاظ على طول أدنى 2
                    val shrinkCount = (1 + abs(totalPendingGrowth)).coerceAtMost((expanded.size - 2).coerceAtLeast(0))
                    expanded.dropLast(shrinkCount)
                }
                else -> {
                    // حركة طبيعية بدون نمو
                    expanded.dropLast(1)
                }
            }
        }

        val remainingPendingGrowth = when {
            totalPendingGrowth > 0 -> totalPendingGrowth - 1
            else -> 0
        }

        val updatedSnake = snake.copy(
            body = updatedBody,
            direction = resolvedDirection,
            pendingGrowth = remainingPendingGrowth
        )

        return SnakeStepResult.Moved(
            snake = updatedSnake,
            eatenFood = eatenPrimary,
            eatenSecondaryFood = eatenSecondary
        )
    }

    fun applyFoodGrowth(snake: Snake, food: Food): Snake {
        return if (food.type.growth >= 0) {
            snake.copy(pendingGrowth = snake.pendingGrowth + food.type.growth)
        } else {
            val targetSize = (snake.body.size + food.type.growth).coerceAtLeast(2)
            snake.copy(body = snake.body.take(targetSize))
        }
    }
}

class SnakeViewModel(application: Application) : AndroidViewModel(application) {

    private val prefs = GamePreferences(application)
    private val soundManager = SoundAndHapticManager(application)

    private var gameJob: Job? = null
    private var particleJob: Job? = null
    private val directionQueue = ArrayDeque<Direction>()

    // تذكر حالة الإيقاف قبل دخول الإعدادات حتى تبقى متوقفة حتى الخروج وتستأنف بعدها فقط إذا كانت نشطة
    private var wasPausedBeforeSettings: Boolean = false
    private var wasPausedBeforeStats: Boolean = false

    /**
     * الحالة الرئيسية باستخدام Jetpack Compose State (mutableStateOf)
     */
    var uiState by mutableStateOf(createInitialState())
        private set

    init {
        startNewGame()
        startParticleAndPopupLoop()
    }

    private fun createInitialState(): SnakeUiState {
        val mode = prefs.selectedMode
        return SnakeUiState(
            mode = mode,
            speed = prefs.selectedSpeed,
            skin = prefs.selectedSkin,
            boardTheme = prefs.selectedBoardTheme,
            controlsType = prefs.controlsType,
            isSoundEnabled = prefs.isSoundEnabled,
            isHapticEnabled = prefs.isHapticEnabled,
            highScore = prefs.getHighScore(mode),
            totalGamesPlayed = prefs.getTotalGamesPlayed(),
            totalApplesEaten = prefs.getTotalApplesEaten(),
            maxSnakeLength = prefs.getMaxLength(),
            highestComboEver = prefs.getHighestCombo(),
            totalXp = prefs.getTotalXp(),
            missions = buildMissions(0, 0, 1, 4)
        )
    }

    fun startNewGame() {
        gameJob?.cancel()
        directionQueue.clear()
        wasPausedBeforeSettings = false
        wasPausedBeforeStats = false

        val gridW = 20
        val gridH = 24
        val startSnake = Snake(
            body = listOf(
                Point(gridW / 2, gridH / 2),
                Point(gridW / 2 - 1, gridH / 2),
                Point(gridW / 2 - 2, gridH / 2),
                Point(gridW / 2 - 3, gridH / 2)
            ),
            direction = Direction.RIGHT,
            pendingGrowth = 0
        )

        val currentMode = uiState.mode
        val obstacles = if (currentMode == GameMode.OBSTACLES) {
            generateObstacles(gridW, gridH, startSnake.body)
        } else {
            emptyList()
        }

        val firstFood = spawnFood(
            gridW = gridW,
            gridH = gridH,
            snakeBody = startSnake.body,
            obstacles = obstacles,
            occupied = emptyList(),
            type = FoodType.NORMAL
        )

        prefs.incrementGamesPlayed()

        uiState = uiState.copy(
            gridWidth = gridW,
            gridHeight = gridH,
            snake = startSnake,
            food = firstFood,
            secondaryFood = null,
            obstacles = obstacles,
            score = 0,
            highScore = prefs.getHighScore(currentMode),
            applesEatenThisGame = 0,
            comboCount = 0,
            comboMultiplier = 1,
            lastEatTimeMillis = 0L,
            activePowerUps = emptyList(),
            particles = emptyList(),
            scorePopups = emptyList(),
            isPaused = false,
            isSettingsOpen = false,
            isStatsOpen = false,
            isGameOver = false,
            canRevive = true,
            isTurboActive = false,
            deathReason = "",
            totalGamesPlayed = prefs.getTotalGamesPlayed(),
            isNewRecord = false,
            missions = buildMissions(0, 0, 1, startSnake.length)
        )

        launchGameLoop()
    }

    fun reviveGame() {
        if (!uiState.isGameOver || !uiState.canRevive) return

        directionQueue.clear()
        val gridW = uiState.gridWidth
        val gridH = uiState.gridHeight
        val currentLength = uiState.snake.length.coerceIn(4, 10)
        val safeHead = Point(gridW / 2, gridH / 2)
        val revivedBody = (0 until currentLength).map { idx ->
            Point((safeHead.x - idx + gridW) % gridW, safeHead.y)
        }
        val revivedSnake = Snake(
            body = revivedBody,
            direction = Direction.RIGHT,
            pendingGrowth = 0
        )

        val now = System.currentTimeMillis()
        val shield = ActivePowerUp(FoodType.STAR, now + 4500L)

        uiState = uiState.copy(
            snake = revivedSnake,
            isGameOver = false,
            isPaused = false,
            canRevive = false,
            deathReason = "",
            activePowerUps = listOf(shield),
            scorePopups = uiState.scorePopups + ScorePopup(
                x = safeHead.x + 0.5f,
                y = safeHead.y.toFloat(),
                text = "إنعاش + درع!",
                isDanger = false
            )
        )

        soundManager.playBonusSound(uiState.isSoundEnabled)
        soundManager.vibrateEat(uiState.isHapticEnabled)
        launchGameLoop()
    }

    private fun launchGameLoop() {
        gameJob?.cancel()
        gameJob = viewModelScope.launch {
            while (isActive) {
                val delayMs = calculateCurrentTickDelay()
                delay(delayMs)
                if (!uiState.isPaused && !uiState.isSettingsOpen && !uiState.isStatsOpen && !uiState.isGameOver) {
                    tickGame()
                }
            }
        }
    }

    private fun calculateCurrentTickDelay(): Long {
        var delayMs = uiState.speed.baseDelayMs
        if (uiState.speed == GameSpeed.DYNAMIC) {
            val reduction = (uiState.applesEatenThisGame * 2L).coerceAtMost(85L)
            delayMs = max(68L, delayMs - reduction)
        }

        val now = System.currentTimeMillis()
        val hasSlowMo = uiState.activePowerUps.any {
            it.type == FoodType.SLOW_MO && it.expiresAtMillis > now
        }
        if (hasSlowMo) {
            delayMs = (delayMs * 1.45f).toLong()
        }

        if (uiState.isTurboActive) {
            delayMs = max(50L, (delayMs * 0.55f).toLong())
        }
        return delayMs
    }

    private fun tickGame() {
        val now = System.currentTimeMillis()
        val state = uiState

        val activePowerUps = state.activePowerUps.filter { it.expiresAtMillis > now }
        val isGhostActive = activePowerUps.any { it.type == FoodType.GHOST }
        val isShieldActive = activePowerUps.any { it.type == FoodType.STAR }
        val isMagnetActive = activePowerUps.any { it.type == FoodType.MAGNET }
        val isDoubleScore = activePowerUps.any { it.type == FoodType.DOUBLE_SCORE }

        var activeSecondary = state.secondaryFood?.takeIf {
            it.expiresAtMillis == 0L || it.expiresAtMillis > now
        }

        val nextDirection = if (directionQueue.isNotEmpty()) {
            directionQueue.pollFirst() ?: state.snake.direction
        } else {
            state.snake.direction
        }

        val stepResult = SnakeGameLogic.advanceSnake(
            snake = state.snake,
            nextDirection = nextDirection,
            gridWidth = state.gridWidth,
            gridHeight = state.gridHeight,
            mode = state.mode,
            obstacles = state.obstacles,
            primaryFood = state.food,
            secondaryFood = activeSecondary,
            isGhostActive = isGhostActive,
            isShieldActive = isShieldActive
        )

        when (stepResult) {
            is SnakeStepResult.Collided -> {
                handleGameOver(stepResult.reason, isWallHit = stepResult.isWallHit)
            }

            is SnakeStepResult.Moved -> {
                var movedSnake = stepResult.snake
                var updatedScore = state.score
                var updatedApples = state.applesEatenThisGame
                var updatedComboCount = state.comboCount
                var updatedComboMult = state.comboMultiplier
                var updatedLastEat = state.lastEatTimeMillis
                val newParticles = state.particles.toMutableList()
                val newPopups = state.scorePopups.toMutableList()
                val updatedPowerUps = activePowerUps.toMutableList()

                var primaryFood = state.food
                var secondaryFood = activeSecondary

                val eatenPrimary = stepResult.eatenFood
                if (eatenPrimary != null) {
                    val withinCombo = (now - updatedLastEat) <= 3800L
                    updatedComboCount = if (withinCombo) updatedComboCount + 1 else 1
                    updatedComboMult = (1 + (updatedComboCount / 2)).coerceAtMost(5)
                    updatedLastEat = now

                    val scoreBoost = if (isDoubleScore) 2 else 1
                    val earnedPoints = eatenPrimary.type.points * updatedComboMult * scoreBoost
                    updatedScore = max(0, updatedScore + earnedPoints)
                    updatedApples += 1

                    prefs.incrementApplesEaten(1)
                    prefs.addXp(max(5, earnedPoints / 2))
                    if (updatedComboMult > state.highestComboEver) {
                        prefs.updateHighestCombo(updatedComboMult)
                    }

                    if (updatedComboMult >= 2) {
                        soundManager.playComboSound(updatedComboMult, state.isSoundEnabled)
                    } else {
                        soundManager.playEatSound(state.isSoundEnabled)
                    }
                    soundManager.vibrateEat(state.isHapticEnabled)

                    newParticles.addAll(
                        spawnParticles(eatenPrimary.position, FoodRed, 14)
                    )
                    val label = if (updatedComboMult > 1) {
                        "+$earnedPoints (x$updatedComboMult)"
                    } else {
                        "+$earnedPoints"
                    }
                    newPopups.add(
                        ScorePopup(
                            x = eatenPrimary.position.x + 0.5f,
                            y = eatenPrimary.position.y.toFloat(),
                            text = label,
                            isDanger = false
                        )
                    )

                    primaryFood = spawnFood(
                        gridW = state.gridWidth,
                        gridH = state.gridHeight,
                        snakeBody = movedSnake.body,
                        obstacles = state.obstacles,
                        occupied = listOfNotNull(secondaryFood?.position),
                        type = FoodType.NORMAL
                    )

                    // احتمال ظهور غذاء خاص إضافي
                    if (secondaryFood == null && Random.nextFloat() < 0.35f) {
                        val specialType = pickSpecialFoodType()
                        val pos = spawnFood(
                            gridW = state.gridWidth,
                            gridH = state.gridHeight,
                            snakeBody = movedSnake.body,
                            obstacles = state.obstacles,
                            occupied = listOf(primaryFood.position),
                            type = specialType
                        )
                        secondaryFood = pos.copy(
                            expiresAtMillis = now + specialType.durationSeconds * 1000L
                        )
                    }
                }

                val eatenSecondary = stepResult.eatenSecondaryFood
                if (eatenSecondary != null) {
                    val fType = eatenSecondary.type
                    if (fType == FoodType.POISON_BOMB) {
                        updatedScore = max(0, updatedScore + fType.points)
                        updatedComboCount = 0
                        updatedComboMult = 1
                        soundManager.playBombSound(state.isSoundEnabled)
                        soundManager.vibrateBomb(state.isHapticEnabled)
                        newParticles.addAll(
                            spawnParticles(eatenSecondary.position, Color(0xFFEF4444), 18)
                        )
                        newPopups.add(
                            ScorePopup(
                                x = eatenSecondary.position.x + 0.5f,
                                y = eatenSecondary.position.y.toFloat(),
                                text = "${fType.points} قنبلة!",
                                isDanger = true
                            )
                        )
                    } else {
                        val scoreBoost = if (isDoubleScore) 2 else 1
                        val bonusPts = fType.points * scoreBoost
                        updatedScore += bonusPts
                        if (fType == FoodType.GOLDEN) {
                            prefs.incrementGoldenApples()
                        }
                        prefs.addXp(max(10, bonusPts / 2))
                        soundManager.playBonusSound(state.isSoundEnabled)
                        soundManager.vibrateEat(state.isHapticEnabled)

                        if (fType in listOf(
                                FoodType.SLOW_MO,
                                FoodType.STAR,
                                FoodType.DOUBLE_SCORE,
                                FoodType.MAGNET,
                                FoodType.GHOST
                            )
                        ) {
                            updatedPowerUps.removeAll { it.type == fType }
                            updatedPowerUps.add(
                                ActivePowerUp(
                                    type = fType,
                                    expiresAtMillis = now + fType.durationSeconds * 1000L
                                )
                            )
                        }

                        val pColor = when (fType) {
                            FoodType.GOLDEN -> GoldBonus
                            FoodType.SLOW_MO -> SpeedBlue
                            FoodType.STAR -> StarPurple
                            FoodType.MAGNET -> Color(0xFFEC4899)
                            FoodType.GHOST -> Color(0xFF38BDF8)
                            else -> EmeraldPrimary
                        }
                        newParticles.addAll(spawnParticles(eatenSecondary.position, pColor, 18))
                        newPopups.add(
                            ScorePopup(
                                x = eatenSecondary.position.x + 0.5f,
                                y = eatenSecondary.position.y.toFloat(),
                                text = "+$bonusPts ${fType.titleAr}",
                                isDanger = false
                            )
                        )
                    }
                    secondaryFood = null
                }

                // تأثير المغناطيس: يجذب التفاحة الأساسية خطوة نحو رأس الأفعى
                if (isMagnetActive && eatenPrimary == null) {
                    primaryFood = pullFoodTowardHead(
                        food = primaryFood,
                        head = movedSnake.head,
                        snakeBody = movedSnake.body,
                        obstacles = state.obstacles
                    )
                }

                // تحديث طول الأفعى والأرقام القياسية
                prefs.updateMaxLength(movedSnake.length)
                val prevHigh = state.highScore
                val isNewRecord = updatedScore > prevHigh || state.isNewRecord
                if (updatedScore > prevHigh) {
                    prefs.setHighScore(state.mode, updatedScore)
                }

                val currentHighestCombo = max(state.highestComboEver, updatedComboMult)
                val currentMaxLen = max(state.maxSnakeLength, movedSnake.length)

                uiState = state.copy(
                    snake = movedSnake,
                    food = primaryFood,
                    secondaryFood = secondaryFood,
                    score = updatedScore,
                    highScore = max(prevHigh, updatedScore),
                    applesEatenThisGame = updatedApples,
                    comboCount = updatedComboCount,
                    comboMultiplier = updatedComboMult,
                    lastEatTimeMillis = updatedLastEat,
                    activePowerUps = updatedPowerUps,
                    particles = newParticles,
                    scorePopups = newPopups,
                    totalApplesEaten = prefs.getTotalApplesEaten(),
                    maxSnakeLength = currentMaxLen,
                    highestComboEver = currentHighestCombo,
                    totalXp = prefs.getTotalXp(),
                    isNewRecord = isNewRecord,
                    missions = buildMissions(
                        applesThisGame = updatedApples,
                        scoreThisGame = updatedScore,
                        comboThisGame = updatedComboMult,
                        lengthThisGame = movedSnake.length
                    )
                )
            }
        }
    }

    private fun pullFoodTowardHead(
        food: Food,
        head: Point,
        snakeBody: List<Point>,
        obstacles: List<Point>
    ): Food {
        val dx = (head.x - food.position.x).coerceIn(-1, 1)
        val dy = (head.y - food.position.y).coerceIn(-1, 1)
        val dist = abs(head.x - food.position.x) + abs(head.y - food.position.y)
        if (dist > 6 || dist <= 1) return food

        val candidate = if (abs(head.x - food.position.x) >= abs(head.y - food.position.y)) {
            Point(food.position.x + dx, food.position.y)
        } else {
            Point(food.position.x, food.position.y + dy)
        }
        return if (!snakeBody.contains(candidate) && !obstacles.contains(candidate)) {
            food.copy(position = candidate)
        } else {
            food
        }
    }

    private fun handleGameOver(reason: String, isWallHit: Boolean) {
        gameJob?.cancel()
        if (isWallHit) {
            soundManager.playWallHitSound(uiState.isSoundEnabled)
        }
        soundManager.playGameOverSound(uiState.isSoundEnabled)
        soundManager.vibrateCollision(uiState.isHapticEnabled)

        val currentHigh = prefs.getHighScore(uiState.mode)
        val isRecord = uiState.score > currentHigh || uiState.isNewRecord
        if (uiState.score > currentHigh) {
            prefs.setHighScore(uiState.mode, uiState.score)
        }

        uiState = uiState.copy(
            isGameOver = true,
            isPaused = false,
            isTurboActive = false,
            deathReason = reason,
            highScore = max(currentHigh, uiState.score),
            isNewRecord = isRecord
        )
    }

    fun onDirectionChanged(newDirection: Direction) {
        if (uiState.isPaused || uiState.isSettingsOpen || uiState.isStatsOpen || uiState.isGameOver) {
            return
        }
        val lastPlanned = directionQueue.peekLast() ?: uiState.snake.direction
        if (newDirection == lastPlanned || newDirection.isOpposite(lastPlanned)) {
            return
        }
        if (directionQueue.size < 2) {
            directionQueue.addLast(newDirection)
            soundManager.playTurnSound(uiState.isSoundEnabled)
            soundManager.vibrateShort(uiState.isHapticEnabled)
        }
    }

    fun togglePause() {
        if (uiState.isGameOver || uiState.isSettingsOpen || uiState.isStatsOpen) return
        val nextPaused = !uiState.isPaused
        if (nextPaused) {
            gameJob?.cancel()
            uiState = uiState.copy(isPaused = true, isTurboActive = false)
        } else {
            uiState = uiState.copy(isPaused = false)
            launchGameLoop()
        }
    }

    fun pauseGame() {
        if (!uiState.isGameOver && !uiState.isPaused) {
            gameJob?.cancel()
            uiState = uiState.copy(isPaused = true, isTurboActive = false)
        }
    }

    /**
     * عند الدخول للإعدادات: تتوقف اللعبة فوراً وتبقى متوقفة حتى الخروج من الإعدادات.
     */
    fun openSettings() {
        if (uiState.isSettingsOpen) return
        wasPausedBeforeSettings = uiState.isPaused
        gameJob?.cancel()
        uiState = uiState.copy(
            isSettingsOpen = true,
            isPaused = true,
            isTurboActive = false
        )
    }

    /**
     * عند الخروج من الإعدادات: تُستأنف اللعبة إذا لم تكن متوقفة مسبقاً ولم تنتهِ.
     */
    fun closeSettings() {
        if (!uiState.isSettingsOpen) return
        val shouldResume = !wasPausedBeforeSettings && !uiState.isGameOver && !uiState.isStatsOpen
        uiState = uiState.copy(
            isSettingsOpen = false,
            isPaused = if (uiState.isGameOver) false else !shouldResume
        )
        if (shouldResume) {
            launchGameLoop()
        }
    }

    fun openStats() {
        if (uiState.isStatsOpen) return
        wasPausedBeforeStats = uiState.isPaused
        gameJob?.cancel()
        uiState = uiState.copy(
            isStatsOpen = true,
            isPaused = true,
            isTurboActive = false
        )
    }

    fun closeStats() {
        if (!uiState.isStatsOpen) return
        val shouldResume = !wasPausedBeforeStats && !uiState.isGameOver && !uiState.isSettingsOpen
        uiState = uiState.copy(
            isStatsOpen = false,
            isPaused = if (uiState.isGameOver) false else !shouldResume
        )
        if (shouldResume) {
            launchGameLoop()
        }
    }

    fun setTurboActive(active: Boolean) {
        if (uiState.isPaused || uiState.isSettingsOpen || uiState.isGameOver) {
            if (uiState.isTurboActive) {
                uiState = uiState.copy(isTurboActive = false)
            }
            return
        }
        if (uiState.isTurboActive != active) {
            uiState = uiState.copy(isTurboActive = active)
        }
    }

    fun setControlsType(controlsType: ControlsType) {
        prefs.controlsType = controlsType
        uiState = uiState.copy(controlsType = controlsType)
    }

    fun setGameMode(mode: GameMode) {
        if (uiState.mode == mode) return
        prefs.selectedMode = mode
        uiState = uiState.copy(mode = mode, highScore = prefs.getHighScore(mode))
        startNewGame()
        // إذا تم تغيير الوضع من داخل الإعدادات، نبقي حالة الإعدادات مفتوحة وإيقاف اللعبة مستمراً
    }

    fun setGameModeKeepingSettingsState(mode: GameMode) {
        if (uiState.mode == mode) return
        prefs.selectedMode = mode
        val keepSettings = uiState.isSettingsOpen
        startNewGame()
        if (keepSettings) {
            wasPausedBeforeSettings = false
            gameJob?.cancel()
            uiState = uiState.copy(isSettingsOpen = true, isPaused = true)
        }
    }

    fun setGameSpeed(speed: GameSpeed) {
        prefs.selectedSpeed = speed
        uiState = uiState.copy(speed = speed)
    }

    fun setSnakeSkin(skin: SnakeSkin) {
        prefs.selectedSkin = skin
        uiState = uiState.copy(skin = skin)
    }

    fun setBoardTheme(theme: BoardTheme) {
        prefs.selectedBoardTheme = theme
        uiState = uiState.copy(boardTheme = theme)
    }

    fun toggleSound() {
        val next = !uiState.isSoundEnabled
        prefs.isSoundEnabled = next
        uiState = uiState.copy(isSoundEnabled = next)
    }

    fun toggleHaptic() {
        val next = !uiState.isHapticEnabled
        prefs.isHapticEnabled = next
        uiState = uiState.copy(isHapticEnabled = next)
        if (next) soundManager.vibrateShort(true)
    }

    private fun startParticleAndPopupLoop() {
        particleJob?.cancel()
        particleJob = viewModelScope.launch {
            while (isActive) {
                delay(32L)
                val state = uiState
                if (state.particles.isEmpty() && state.scorePopups.isEmpty()) continue

                val nextParticles = state.particles.mapNotNull { p ->
                    val nextAlpha = p.alpha - 0.055f
                    if (nextAlpha <= 0f) null
                    else p.copy(
                        x = p.x + p.vx,
                        y = p.y + p.vy,
                        alpha = nextAlpha
                    )
                }

                val nextPopups = state.scorePopups.mapNotNull { pop ->
                    val nextAlpha = pop.alpha - 0.032f
                    if (nextAlpha <= 0f) null
                    else pop.copy(
                        y = pop.y - 0.045f,
                        alpha = nextAlpha
                    )
                }

                uiState = state.copy(
                    particles = nextParticles,
                    scorePopups = nextPopups
                )
            }
        }
    }

    private fun spawnFood(
        gridW: Int,
        gridH: Int,
        snakeBody: List<Point>,
        obstacles: List<Point>,
        occupied: List<Point>,
        type: FoodType
    ): Food {
        val blocked = HashSet<Point>(snakeBody.size + obstacles.size + occupied.size).apply {
            addAll(snakeBody)
            addAll(obstacles)
            addAll(occupied)
        }
        val available = ArrayList<Point>(gridW * gridH)
        for (x in 0 until gridW) {
            for (y in 0 until gridH) {
                val pt = Point(x, y)
                if (!blocked.contains(pt)) available.add(pt)
            }
        }
        val pos = if (available.isNotEmpty()) {
            available[Random.nextInt(available.size)]
        } else {
            Point(0, 0)
        }
        return Food(position = pos, type = type, expiresAtMillis = 0L)
    }

    private fun pickSpecialFoodType(): FoodType {
        val roll = Random.nextInt(100)
        return when {
            roll < 25 -> FoodType.GOLDEN
            roll < 42 -> FoodType.DOUBLE_SCORE
            roll < 56 -> FoodType.SLOW_MO
            roll < 70 -> FoodType.STAR
            roll < 82 -> FoodType.MAGNET
            roll < 92 -> FoodType.GHOST
            else -> FoodType.POISON_BOMB
        }
    }

    private fun generateObstacles(gridW: Int, gridH: Int, snakeBody: List<Point>): List<Point> {
        val obstacles = mutableListOf<Point>()
        val centerY = gridH / 2
        val safeRow = (centerY - 1..centerY + 1)
        val candidates = listOf(
            Point(4, 4), Point(5, 4), Point(4, 5),
            Point(gridW - 5, 4), Point(gridW - 6, 4), Point(gridW - 5, 5),
            Point(4, gridH - 5), Point(5, gridH - 5), Point(4, gridH - 6),
            Point(gridW - 5, gridH - 5), Point(gridW - 6, gridH - 5), Point(gridW - 5, gridH - 6),
            Point(gridW / 2, 5), Point(gridW / 2 - 1, 5),
            Point(gridW / 2, gridH - 6), Point(gridW / 2 - 1, gridH - 6)
        )
        for (pt in candidates) {
            if (pt.y !in safeRow && !snakeBody.contains(pt)) {
                obstacles.add(pt)
            }
        }
        return obstacles
    }

    private fun spawnParticles(point: Point, color: Color, count: Int): List<Particle> {
        return List(count) {
            Particle(
                x = point.x + 0.5f,
                y = point.y + 0.5f,
                vx = (Random.nextFloat() - 0.5f) * 0.42f,
                vy = (Random.nextFloat() - 0.5f) * 0.42f,
                color = color,
                alpha = 1f,
                radius = Random.nextFloat() * 5f + 3f
            )
        }
    }

    private fun buildMissions(
        applesThisGame: Int,
        scoreThisGame: Int,
        comboThisGame: Int,
        lengthThisGame: Int
    ): List<GameMission> {
        return listOf(
            GameMission(
                id = "eat_10",
                titleAr = "صائد التفاح",
                descAr = "تناول 10 أطعمة في جولة واحدة",
                targetCount = 10,
                currentCount = min(applesThisGame, 10),
                isCompleted = applesThisGame >= 10,
                rewardScore = 50,
                iconEmoji = "🍎"
            ),
            GameMission(
                id = "combo_3",
                titleAr = "سيد الكومبو",
                descAr = "حقق مضاعف كومبو x3",
                targetCount = 3,
                currentCount = min(comboThisGame, 3),
                isCompleted = comboThisGame >= 3,
                rewardScore = 75,
                iconEmoji = "⚡"
            ),
            GameMission(
                id = "length_15",
                titleAr = "الأفعى العملاقة",
                descAr = "اوصل بطول الأفعى إلى 15",
                targetCount = 15,
                currentCount = min(lengthThisGame, 15),
                isCompleted = lengthThisGame >= 15,
                rewardScore = 100,
                iconEmoji = "🐍"
            ),
            GameMission(
                id = "score_200",
                titleAr = "بطل الساحة",
                descAr = "اجمع 200 نقطة في جولة واحدة",
                targetCount = 200,
                currentCount = min(scoreThisGame, 200),
                isCompleted = scoreThisGame >= 200,
                rewardScore = 150,
                iconEmoji = "🏆"
            )
        )
    }

    override fun onCleared() {
        super.onCleared()
        gameJob?.cancel()
        particleJob?.cancel()
        soundManager.release()
    }
}
