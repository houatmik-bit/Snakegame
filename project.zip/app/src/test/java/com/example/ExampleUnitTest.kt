package com.example

import com.example.model.ControlsType
import com.example.model.Direction
import com.example.model.Food
import com.example.model.FoodType
import com.example.model.GameMode
import com.example.model.Point
import com.example.model.Snake
import com.example.viewmodel.SnakeGameLogic
import com.example.viewmodel.SnakeStepResult
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

    @Test
    fun `snake moves one step in active direction without growth`() {
        val snake = Snake(
            body = listOf(Point(5, 5), Point(4, 5), Point(3, 5)),
            direction = Direction.RIGHT
        )

        val result = SnakeGameLogic.advanceSnake(
            snake = snake,
            nextDirection = Direction.RIGHT,
            gridWidth = 20,
            gridHeight = 20,
            mode = GameMode.CLASSIC
        )

        assertTrue(result is SnakeStepResult.Moved)
        val moved = (result as SnakeStepResult.Moved).snake
        assertEquals(Point(6, 5), moved.head)
        assertEquals(3, moved.length)
        assertEquals(listOf(Point(6, 5), Point(5, 5), Point(4, 5)), moved.body)
    }

    @Test
    fun `snake grows in length when eating normal food`() {
        val snake = Snake(
            body = listOf(Point(5, 5), Point(4, 5), Point(3, 5)),
            direction = Direction.RIGHT
        )
        val food = Food(position = Point(6, 5), type = FoodType.NORMAL)

        val result = SnakeGameLogic.advanceSnake(
            snake = snake,
            nextDirection = Direction.RIGHT,
            gridWidth = 20,
            gridHeight = 20,
            mode = GameMode.CLASSIC,
            primaryFood = food
        )

        assertTrue(result is SnakeStepResult.Moved)
        val movedResult = result as SnakeStepResult.Moved
        assertEquals(food, movedResult.eatenFood)
        assertEquals(4, movedResult.snake.length)
        assertEquals(Point(6, 5), movedResult.snake.head)
        assertEquals(0, movedResult.snake.pendingGrowth)
    }

    @Test
    fun `snake grows by 2 steps when eating golden food`() {
        val snake = Snake(
            body = listOf(Point(5, 5), Point(4, 5), Point(3, 5)),
            direction = Direction.RIGHT
        )
        val goldenFood = Food(position = Point(6, 5), type = FoodType.GOLDEN)

        val step1 = SnakeGameLogic.advanceSnake(
            snake = snake,
            nextDirection = Direction.RIGHT,
            gridWidth = 20,
            gridHeight = 20,
            mode = GameMode.CLASSIC,
            secondaryFood = goldenFood
        ) as SnakeStepResult.Moved

        assertEquals(4, step1.snake.length)
        assertEquals(1, step1.snake.pendingGrowth)

        val step2 = SnakeGameLogic.advanceSnake(
            snake = step1.snake,
            nextDirection = Direction.DOWN,
            gridWidth = 20,
            gridHeight = 20,
            mode = GameMode.CLASSIC
        ) as SnakeStepResult.Moved

        assertEquals(5, step2.snake.length)
        assertEquals(0, step2.snake.pendingGrowth)
        assertEquals(Point(6, 6), step2.snake.head)
    }

    @Test
    fun `opposite direction input is ignored`() {
        val snake = Snake(
            body = listOf(Point(5, 5), Point(4, 5), Point(3, 5)),
            direction = Direction.RIGHT
        )

        val result = SnakeGameLogic.advanceSnake(
            snake = snake,
            nextDirection = Direction.LEFT,
            gridWidth = 20,
            gridHeight = 20,
            mode = GameMode.CLASSIC
        ) as SnakeStepResult.Moved

        assertEquals(Direction.RIGHT, result.snake.direction)
        assertEquals(Point(6, 5), result.snake.head)
    }

    @Test
    fun `wall collision ends game in classic mode and wraps in endless mode`() {
        val snakeAtEdge = Snake(
            body = listOf(Point(19, 5), Point(18, 5), Point(17, 5)),
            direction = Direction.RIGHT
        )

        val classicResult = SnakeGameLogic.advanceSnake(
            snake = snakeAtEdge,
            nextDirection = Direction.RIGHT,
            gridWidth = 20,
            gridHeight = 20,
            mode = GameMode.CLASSIC
        )
        assertTrue(classicResult is SnakeStepResult.Collided)

        val endlessResult = SnakeGameLogic.advanceSnake(
            snake = snakeAtEdge,
            nextDirection = Direction.RIGHT,
            gridWidth = 20,
            gridHeight = 20,
            mode = GameMode.ENDLESS
        )
        assertTrue(endlessResult is SnakeStepResult.Moved)
        assertEquals(Point(0, 5), (endlessResult as SnakeStepResult.Moved).snake.head)
    }

    @Test
    fun `controls include both joystick and arrow dpad`() {
        val values = ControlsType.entries
        assertTrue(values.contains(ControlsType.JOYSTICK))
        assertTrue(values.contains(ControlsType.DPAD))
    }
}
