package com.example

import android.app.Application
import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.ControlsType
import com.example.viewmodel.SnakeViewModel
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("لعبة الأفعى", appName)
    }

    @Test
    fun `entering settings pauses game until exiting settings`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = SnakeViewModel(app)

        assertFalse(viewModel.uiState.isPaused)
        assertFalse(viewModel.uiState.isSettingsOpen)

        viewModel.openSettings()
        assertTrue(viewModel.uiState.isSettingsOpen)
        assertTrue(viewModel.uiState.isPaused)

        // محاولة إلغاء الإيقاف أثناء فتح الإعدادات يجب ألا تنجح
        viewModel.togglePause()
        assertTrue(viewModel.uiState.isPaused)

        // الخروج من الإعدادات يستأنف اللعبة تلقائياً
        viewModel.closeSettings()
        assertFalse(viewModel.uiState.isSettingsOpen)
        assertFalse(viewModel.uiState.isPaused)
    }

    @Test
    fun `switching between analog joystick and arrow controls updates compose state`() {
        val app = ApplicationProvider.getApplicationContext<Application>()
        val viewModel = SnakeViewModel(app)

        viewModel.setControlsType(ControlsType.DPAD)
        assertEquals(ControlsType.DPAD, viewModel.uiState.controlsType)

        viewModel.setControlsType(ControlsType.JOYSTICK)
        assertEquals(ControlsType.JOYSTICK, viewModel.uiState.controlsType)
    }
}
